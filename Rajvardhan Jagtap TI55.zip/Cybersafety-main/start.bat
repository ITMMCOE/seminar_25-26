@echo off
echo ============================================================
echo    AI-Powered Cyber Safety System - Quick Start
echo ============================================================
echo.
echo Starting the application...
echo.
echo NOTE: First run may take 2-5 minutes to download AI model
echo       Please be patient and keep this window open
echo.
echo ============================================================
echo.

cd /d C:\Cybersafety
C:\Cybersafety\.venv\Scripts\python.exe app.py

pause
