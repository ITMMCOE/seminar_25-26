import os
import json
import base64
import datetime
from flask import Flask, render_template, request, jsonify, send_file
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
import hashlib
from transformers import pipeline
import re

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key-here')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*")

# Create necessary directories
os.makedirs('uploads', exist_ok=True)
os.makedirs('reports', exist_ok=True)
os.makedirs('model', exist_ok=True)

# Initialize AI model for harassment detection
print("Loading AI model... This may take a moment.")
try:
    # Using a toxicity detection model
    classifier = pipeline("text-classification", model="unitary/toxic-bert", top_k=None)
    print("AI model loaded successfully!")
except Exception as e:
    print(f"Warning: Could not load AI model: {e}")
    classifier = None

# In-memory storage for chat sessions, reports, and users
chat_sessions = {}
report_counter = 0
users_db = {}  # In production, use a proper database

# Admin credentials (fixed)
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'

# Encryption key (in production, this should be securely stored)
ENCRYPTION_KEY = os.getenv('ENCRYPTION_KEY', 'cybersafety2025key!!').encode('utf-8')
ENCRYPTION_KEY = hashlib.sha256(ENCRYPTION_KEY).digest()  # Ensure 32 bytes for AES-256

def encrypt_data(data):
    """Encrypt data using AES-256"""
    try:
        # Generate a random IV
        iv = os.urandom(16)
        cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
        encryptor = cipher.encryptor()
        
        # Pad the data
        padder = padding.PKCS7(128).padder()
        padded_data = padder.update(data.encode('utf-8')) + padder.finalize()
        
        # Encrypt
        encrypted = encryptor.update(padded_data) + encryptor.finalize()
        
        # Return IV + encrypted data as base64
        return base64.b64encode(iv + encrypted).decode('utf-8')
    except Exception as e:
        print(f"Encryption error: {e}")
        return None

def decrypt_data(encrypted_data):
    """Decrypt data using AES-256"""
    try:
        # Decode from base64
        data = base64.b64decode(encrypted_data)
        
        # Extract IV and encrypted data
        iv = data[:16]
        encrypted = data[16:]
        
        # Decrypt
        cipher = Cipher(algorithms.AES(ENCRYPTION_KEY), modes.CBC(iv), backend=default_backend())
        decryptor = cipher.decryptor()
        padded_data = decryptor.update(encrypted) + decryptor.finalize()
        
        # Unpad
        unpadder = padding.PKCS7(128).unpadder()
        data = unpadder.update(padded_data) + unpadder.finalize()
        
        return data.decode('utf-8')
    except Exception as e:
        print(f"Decryption error: {e}")
        return None

def analyze_text(text):
    """Analyze text for harassment using AI model"""
    if not classifier:
        # Fallback to keyword-based detection
        return keyword_based_detection(text)
    
    try:
        results = classifier(text)[0]
        
        # Find the toxic label
        toxic_score = 0
        for result in results:
            if result['label'].lower() == 'toxic':
                toxic_score = result['score']
                break
        
        is_harassment = toxic_score > 0.5
        confidence = toxic_score * 100
        
        # Extract offensive words
        offensive_words = extract_offensive_words(text)
        
        explanation = generate_explanation(text, offensive_words, is_harassment)
        
        return {
            'is_harassment': is_harassment,
            'confidence': round(confidence, 2),
            'offensive_words': offensive_words,
            'explanation': explanation
        }
    except Exception as e:
        print(f"AI analysis error: {e}")
        return keyword_based_detection(text)

def keyword_based_detection(text):
    """Fallback keyword-based harassment detection"""
    offensive_keywords = [
        'loser', 'stupid', 'idiot', 'hate', 'kill', 'die', 'ugly', 'fat',
        'slut', 'whore', 'bitch', 'bastard', 'fuck', 'shit', 'damn',
        'retard', 'moron', 'dumb', 'worthless', 'pathetic', 'useless'
    ]
    
    text_lower = text.lower()
    found_words = [word for word in offensive_keywords if word in text_lower]
    
    is_harassment = len(found_words) > 0
    confidence = min(len(found_words) * 30 + 50, 95) if is_harassment else 5
    
    explanation = f"Detected offensive terms: {', '.join(found_words)}" if found_words else "No offensive content detected."
    
    return {
        'is_harassment': is_harassment,
        'confidence': confidence,
        'offensive_words': found_words,
        'explanation': explanation
    }

def extract_offensive_words(text):
    """Extract potentially offensive words from text"""
    offensive_keywords = [
        'loser', 'stupid', 'idiot', 'hate', 'kill', 'die', 'ugly', 'fat',
        'slut', 'whore', 'bitch', 'bastard', 'fuck', 'shit', 'damn',
        'retard', 'moron', 'dumb', 'worthless', 'pathetic', 'useless'
    ]
    
    text_lower = text.lower()
    found_words = []
    
    for word in offensive_keywords:
        if re.search(r'\b' + word + r'\b', text_lower):
            found_words.append(word)
    
    return found_words

def generate_explanation(text, offensive_words, is_harassment):
    """Generate human-readable explanation for AI decision"""
    if is_harassment and offensive_words:
        words_str = ', '.join([f"'{word}'" for word in offensive_words])
        return f"The message contains potentially harmful language. Flagged words: {words_str}. These terms are commonly associated with harassment and abusive behavior."
    elif is_harassment:
        return "The message's tone and context suggest potential harassment based on linguistic patterns associated with abusive communication."
    else:
        return "No harassment detected. The message appears to be safe and respectful."

# ==================== AUTH ROUTES ====================

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/admin/login')
def admin_login():
    return render_template('admin_login.html')

# User authentication routes
@app.route('/api/auth/signup', methods=['POST'])
def signup():
    data = request.json
    username = data.get('username')
    mobile = data.get('mobile')
    password = data.get('password')
    
    if username in users_db:
        return jsonify({'success': False, 'message': 'Username already exists'}), 400
    
    users_db[username] = {
        'username': username,
        'mobile': mobile,
        'password': password  # In production, hash this!
    }
    
    return jsonify({'success': True, 'message': 'Account created successfully'})

@app.route('/api/auth/signin', methods=['POST'])
def signin():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if username not in users_db or users_db[username]['password'] != password:
        return jsonify({'success': False, 'message': 'Invalid credentials'}), 401
    
    user = {
        'username': username,
        'mobile': users_db[username]['mobile']
    }
    
    return jsonify({'success': True, 'user': user})

@app.route('/api/auth/admin/signin', methods=['POST'])
def admin_signin():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if username != ADMIN_USERNAME or password != ADMIN_PASSWORD:
        return jsonify({'success': False, 'message': 'Invalid admin credentials'}), 401
    
    admin = {
        'username': username,
        'role': 'admin'
    }
    
    return jsonify({'success': True, 'admin': admin})

# ==================== USER ROUTES ====================

@app.route('/user/dashboard')
def user_dashboard():
    return render_template('user_dashboard.html')

@app.route('/user/detect')
def user_detect():
    return render_template('detect.html')

@app.route('/user/evidence')
def user_evidence():
    return render_template('evidence.html')

@app.route('/user/emergency')
def user_emergency():
    return render_template('emergency.html')

# ==================== ADMIN ROUTES ====================

@app.route('/admin/dashboard')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/admin/chats')
def admin_chats():
    return render_template('admin.html')

@app.route('/admin/reports')
def admin_reports():
    return render_template('admin.html')

@app.route('/admin/join-chat')
def admin_join_chat():
    return render_template('admin.html')

@app.route('/api/analyze', methods=['POST'])
def analyze():
    """Analyze text for harassment"""
    data = request.json
    text = data.get('text', '')
    
    if not text:
        return jsonify({'error': 'No text provided'}), 400
    
    result = analyze_text(text)
    
    return jsonify({
        'result': 'Harassment Detected' if result['is_harassment'] else 'Safe Message',
        'is_harassment': result['is_harassment'],
        'confidence': result['confidence'],
        'offensive_words': result['offensive_words'],
        'explanation': result['explanation'],
        'analyzed_text': text
    })

@app.route('/api/save-report', methods=['POST'])
def save_report():
    """Save encrypted evidence report"""
    global report_counter
    
    data = request.json
    report_counter += 1
    
    # Create report
    report = {
        'report_id': f"RPT-{datetime.datetime.now().year}-{report_counter:03d}",
        'datetime': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'user': data.get('user', 'Anonymous'),
        'input_text': data.get('input_text', ''),
        'result': data.get('result', ''),
        'confidence': data.get('confidence', 0),
        'explanation': data.get('explanation', ''),
        'offensive_words': data.get('offensive_words', []),
        'uploaded_evidence': data.get('uploaded_evidence', []),
        'chat_id': data.get('chat_id', ''),
        'encryption': 'AES-256 | Stored Locally'
    }
    
    # Encrypt and save
    report_json = json.dumps(report, indent=2)
    encrypted_report = encrypt_data(report_json)
    
    if encrypted_report:
        filename = f"report_{report['report_id']}.enc"
        filepath = os.path.join('reports', filename)
        
        with open(filepath, 'w') as f:
            f.write(encrypted_report)
        
        return jsonify({
            'success': True,
            'report_id': report['report_id'],
            'filename': filename,
            'message': 'Encrypted report saved successfully'
        })
    else:
        return jsonify({'error': 'Encryption failed'}), 500

@app.route('/api/upload-evidence', methods=['POST'])
def upload_evidence():
    """Upload and encrypt evidence image"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Read and encrypt file
    file_data = file.read()
    encrypted_data = encrypt_data(base64.b64encode(file_data).decode('utf-8'))
    
    if encrypted_data:
        filename = f"evidence_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.enc"
        filepath = os.path.join('uploads', filename)
        
        with open(filepath, 'w') as f:
            f.write(encrypted_data)
        
        return jsonify({
            'success': True,
            'filename': filename,
            'message': 'Evidence uploaded and encrypted successfully'
        })
    else:
        return jsonify({'error': 'Encryption failed'}), 500

@app.route('/api/reports', methods=['GET'])
def get_reports():
    """Get list of all encrypted reports"""
    reports = []
    
    if os.path.exists('reports'):
        for filename in os.listdir('reports'):
            if filename.endswith('.enc'):
                reports.append({
                    'filename': filename,
                    'created': datetime.datetime.fromtimestamp(
                        os.path.getctime(os.path.join('reports', filename))
                    ).strftime('%Y-%m-%d %H:%M:%S')
                })
    
    return jsonify({'reports': reports})

@app.route('/api/decrypt-report/<filename>', methods=['GET'])
def decrypt_report(filename):
    """Decrypt and return report (admin only)"""
    filepath = os.path.join('reports', filename)
    
    if not os.path.exists(filepath):
        return jsonify({'error': 'Report not found'}), 404
    
    with open(filepath, 'r') as f:
        encrypted_data = f.read()
    
    decrypted_data = decrypt_data(encrypted_data)
    
    if decrypted_data:
        report = json.loads(decrypted_data)
        return jsonify({'success': True, 'report': report})
    else:
        return jsonify({'error': 'Decryption failed'}), 500

@app.route('/api/chats', methods=['GET'])
def get_chats():
    """Get list of all chat sessions"""
    chats = []
    
    for chat_id, session in chat_sessions.items():
        chats.append({
            'chat_id': chat_id,
            'started': session['started'],
            'user_name': session['user_name'],
            'message_count': len(session['messages'])
        })
    
    return jsonify({'chats': chats})

@app.route('/api/chat/<chat_id>', methods=['GET'])
def get_chat(chat_id):
    """Get chat session details"""
    if chat_id not in chat_sessions:
        return jsonify({'error': 'Chat not found'}), 404
    
    return jsonify({'success': True, 'chat': chat_sessions[chat_id]})

# Socket.IO events for real-time chat
@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('connected', {'message': 'Connected to emergency support'})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

@socketio.on('start_chat')
def handle_start_chat(data):
    """Start a new chat session"""
    chat_id = f"CHAT-{len(chat_sessions) + 1:04d}"
    user_name = data.get('user_name', 'Anonymous')
    
    chat_sessions[chat_id] = {
        'chat_id': chat_id,
        'user_name': user_name,
        'started': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'messages': []
    }
    
    emit('chat_started', {'chat_id': chat_id, 'message': 'Emergency chat initiated. An officer will assist you shortly.'})

@socketio.on('send_message')
def handle_message(data):
    """Handle incoming chat message"""
    chat_id = data.get('chat_id')
    message = data.get('message')
    sender = data.get('sender', 'user')
    
    if chat_id not in chat_sessions:
        emit('error', {'message': 'Invalid chat session'})
        return
    
    # Store message
    message_data = {
        'sender': sender,
        'message': message,
        'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    }
    
    chat_sessions[chat_id]['messages'].append(message_data)
    
    # Broadcast to all clients in this chat
    emit('new_message', message_data, broadcast=True)

@socketio.on('officer_join')
def handle_officer_join(data):
    """Officer joins a chat"""
    chat_id = data.get('chat_id')
    
    if chat_id in chat_sessions:
        message_data = {
            'sender': 'system',
            'message': 'A cybersecurity officer has joined the chat.',
            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        chat_sessions[chat_id]['messages'].append(message_data)
        emit('new_message', message_data, broadcast=True)

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🔒 AI-Powered Cyber Safety System")
    print("="*60)
    print("\nStarting server...")
    print("Access the application at: http://localhost:5000")
    print("\nPress CTRL+C to stop the server")
    print("="*60 + "\n")
    
    socketio.run(app, debug=True, host='0.0.0.0', port=5000, allow_unsafe_werkzeug=True)
