# 🔒 AI-Powered Cyber Safety & Harassment Detection System

## Overview

A privacy-first web application prototype demonstrating an AI-powered cyber safety system for women and children. The platform detects online harassment using NLP, provides explainable AI results, encrypts evidence locally using AES-256, and enables real-time emergency chat with cybersecurity officers.

## 🌟 Features

- **🤖 AI Harassment Detection**: Analyzes text using pre-trained NLP models to detect abusive content
- **💡 Explainable AI**: Highlights offensive words and explains detection reasoning
- **🔐 AES-256 Encryption**: All evidence and reports encrypted locally
- **💬 Real-Time Emergency Chat**: Socket.IO-based instant messaging with officers
- **📸 Evidence Upload**: Upload and encrypt screenshots as evidence
- **📋 Automated Reports**: Generates detailed encrypted evidence reports
- **👮 Admin Panel**: Officer interface to monitor chats and decrypt reports
- **🔒 Privacy-First**: All processing done locally, no external data transmission

## 📋 Prerequisites

- Python 3.8 or higher
- pip (Python package installer)
- Modern web browser (Chrome, Firefox, Edge, Safari)

## 🚀 Installation

### 1. Navigate to Project Directory

```powershell
cd C:\Cybersafety
```

### 2. Create Virtual Environment (Recommended)

```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### 3. Install Dependencies

```powershell
pip install -r requirements.txt
```

**Note**: The first installation may take several minutes as it downloads the AI model (toxic-bert) which is approximately 500MB.

## ⚙️ Configuration

The `.env` file contains all configuration settings:

```env
SECRET_KEY=cybersafety-secure-key-2025-change-this-in-production
ENCRYPTION_KEY=cybersafety2025key!!
FLASK_ENV=development
FLASK_DEBUG=True
HOST=0.0.0.0
PORT=5000
```

**Important**: Change `SECRET_KEY` and `ENCRYPTION_KEY` to strong random values in production!

## 🏃 Running the Application

### Start the Server

```powershell
python app.py
```

The application will be available at:

- **Local**: http://localhost:5000
- **Network**: http://YOUR_IP:5000

### Accessing the Application

1. **Home Page**: http://localhost:5000/
2. **Detection Page**: http://localhost:5000/detect
3. **Evidence Reports**: http://localhost:5000/evidence
4. **Emergency Chat**: http://localhost:5000/emergency
5. **Admin Panel**: http://localhost:5000/admin

## 📖 User Guide

### For Users (Detecting Harassment)

1. **Navigate to Detection Page**

   - Enter text you want to analyze
   - Click "Analyze Text"
   - View AI results with explanation

2. **Save Evidence**

   - After analysis, click "Save Encrypted Report"
   - Report is encrypted and stored locally

3. **Emergency Help**
   - Click "Emergency Help" in navigation
   - Enter your name (optional)
   - Click "Start Emergency Chat"
   - Chat in real-time with an officer
   - Upload evidence images if needed

### For Officers (Admin Panel)

1. **Monitor Active Chats**

   - View all active emergency chats
   - See user information and message count

2. **Join Chats**

   - Click "Join Chat" on any active session
   - Respond to users in real-time
   - Request evidence uploads

3. **View Encrypted Reports**
   - Browse all encrypted reports
   - Click "Decrypt & View" to see full details
   - Review harassment evidence

## 🧪 Testing the System

### Test Harassment Detection

Try these sample texts:

**Harassment Examples**:

- "You're such a loser"
- "I hate you, you're worthless"
- "You should just die"

**Safe Examples**:

- "Have a great day!"
- "Thank you for your help"
- "That's an interesting point"

### Test Emergency Chat

1. Open http://localhost:5000/emergency in one browser tab (User)
2. Open http://localhost:5000/admin in another tab (Officer)
3. Start chat from user side
4. Join chat from admin panel
5. Exchange messages

### Test Evidence Upload

1. Analyze text on detection page
2. Save report
3. Go to Evidence page
4. Upload an image
5. View encrypted evidence in Admin panel

## 📁 Project Structure

```
C:\Cybersafety\
├── app.py                  # Main Flask application
├── requirements.txt        # Python dependencies
├── .env                    # Configuration file
├── instructions.md         # Full project requirements
├── README.md              # This file
├── templates/             # HTML templates
│   ├── index.html         # Home page
│   ├── detect.html        # Detection interface
│   ├── evidence.html      # Evidence management
│   ├── emergency.html     # Emergency chat
│   └── admin.html         # Admin panel
├── static/                # Static assets
│   ├── style.css          # Main stylesheet
│   └── script.js          # JavaScript utilities
├── uploads/               # Encrypted evidence images
├── reports/               # Encrypted evidence reports
└── model/                 # AI model cache
```

## 🔧 Troubleshooting

### Port Already in Use

```powershell
# Change PORT in .env file or kill the process
netstat -ano | findstr :5000
taskkill /PID <PID> /F
```

### AI Model Not Loading

- Ensure you have stable internet for first download
- Model is cached after first use
- Check console for error messages
- Fallback keyword detection will activate automatically

### Socket.IO Connection Issues

- Ensure firewall allows local connections
- Check if port 5000 is accessible
- Try accessing via 127.0.0.1 instead of localhost

### Virtual Environment Issues

```powershell
# Deactivate and recreate
deactivate
Remove-Item -Recurse -Force venv
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

## 🔒 Security Notes

- **Local Only**: This is a prototype for demonstration purposes
- **Encryption**: Uses AES-256 with PKCS7 padding
- **Keys**: Change encryption keys before any production use
- **Storage**: All data stored locally in `uploads/` and `reports/`
- **No External Calls**: All AI processing happens locally

## 📊 Technical Stack

| Component      | Technology                             |
| -------------- | -------------------------------------- |
| Backend        | Python Flask + Flask-SocketIO          |
| Frontend       | HTML5, CSS3, JavaScript                |
| AI Model       | Hugging Face Transformers (toxic-bert) |
| Encryption     | Cryptography library (AES-256)         |
| Real-Time Chat | Socket.IO                              |
| Storage        | Local file system                      |

## 🎓 Seminar Presentation Tips

1. **Start with Overview**: Explain the problem of online harassment
2. **Demo Detection**: Show live text analysis with explanations
3. **Show Encryption**: Emphasize privacy and security features
4. **Live Chat Demo**: Demonstrate emergency chat functionality
5. **Admin Panel**: Show how officers can help and decrypt evidence
6. **Discuss Privacy**: Highlight that all processing is local

## 🤝 Contributing

This is a seminar prototype. For improvements:

1. Fork the repository
2. Create feature branch
3. Test thoroughly
4. Submit pull request

## 📝 License

This project is created for educational and demonstration purposes as part of a seminar on cyber safety.

## 👥 Support

For issues or questions:

- Check the troubleshooting section
- Review `instructions.md` for detailed specifications
- Check console logs for error messages

## 🎯 Future Enhancements

- [ ] Multi-language support
- [ ] Advanced ML models (BERT, GPT)
- [ ] Mobile responsive design improvements
- [ ] Export reports to PDF
- [ ] User authentication system
- [ ] Chat history persistence
- [ ] Real-time threat level dashboard

---

**Built with ❤️ for Cyber Safety**

_Last Updated: October 10, 2025_
