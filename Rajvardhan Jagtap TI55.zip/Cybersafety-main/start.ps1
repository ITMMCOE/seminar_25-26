# AI-Powered Cyber Safety System - Quick Start Script
# Double-click this file or run: .\start.ps1

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "   AI-Powered Cyber Safety System - Quick Start" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting the application..." -ForegroundColor Green
Write-Host ""
Write-Host "NOTE: First run may take 2-5 minutes to download AI model" -ForegroundColor Yellow
Write-Host "      Please be patient and keep this window open" -ForegroundColor Yellow
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host ""

Set-Location C:\Cybersafety
& C:\Cybersafety\.venv\Scripts\python.exe app.py

Read-Host "Press Enter to exit"
