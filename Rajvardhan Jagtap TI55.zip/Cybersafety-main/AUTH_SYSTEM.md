# 🔐 Authentication System Update

## New User Authentication System

The Cyber Safety System now has a complete authentication system with separate UIs for users and administrators.

---

## 🚪 Login Pages

### User Login/Signup

**URL**: http://localhost:5000/ or http://localhost:5000/login

**Sign Up Fields:**

- Username (minimum 3 characters)
- Mobile Number (10 digits)
- Password (minimum 6 characters)
- Confirm Password

**Sign In Fields:**

- Username
- Password

### Admin Login

**URL**: http://localhost:5000/admin/login

**Fixed Credentials:**

- Username: `admin`
- Password: `admin123`

---

## 👤 USER PORTAL

After logging in, users have access to:

### User Dashboard

**URL**: `/user/dashboard`

- Welcome screen with quick actions
- Overview of available features

### 1. Detection (Analyze Text)

**URL**: `/user/detect`

- Analyze text for harassment
- AI-powered detection with explanations
- Save encrypted reports

### 2. Evidence

**URL**: `/user/evidence`

- **Encrypted Reports**: View all saved reports
- **Upload Evidence Image**: Upload and encrypt screenshots

### 3. Emergency

**URL**: `/user/emergency`

- **Emergency Chat**: Real-time chat with officers
- Upload evidence during chat
- Panic button for immediate help

---

## 👮 ADMIN PORTAL

After admin login, access to:

### Admin Dashboard

**URL**: `/admin/dashboard`

- Overview statistics
- Quick action buttons
- Recent activity

### 1. Active Chats

**URL**: `/admin/chats`

- View all active emergency chats
- See user information
- Message counts

### 2. Reports

**URL**: `/admin/reports`

- View all encrypted reports
- Decrypt and read full details
- Review harassment evidence

### 3. Join Chat

**URL**: `/admin/join-chat`

- Enter chat ID to join
- Respond to users in real-time
- Provide support

---

## 🔄 How to Use

### For Users:

1. **Sign Up** (First Time):

   - Go to http://localhost:5000/
   - Click "Sign Up" tab
   - Fill in username, mobile, password
   - Click "Sign Up"

2. **Sign In**:

   - Enter username and password
   - Click "Sign In"
   - Redirects to User Dashboard

3. **Use Features**:
   - Access Detection, Evidence, or Emergency from navigation
   - All features work exactly as before
   - Logout from top navigation

### For Admin:

1. **Admin Login**:

   - Go to http://localhost:5000/admin/login
   - Username: `admin`
   - Password: `admin123`
   - Click "Admin Login"

2. **Access Admin Features**:

   - View dashboard statistics
   - Monitor active chats
   - Decrypt and view reports
   - Join emergency chats

3. **Join User Chats**:
   - Go to Active Chats
   - Click "Join Chat" on any active session
   - Or go to "Join Chat" tab
   - Enter Chat ID (e.g., CHAT-0001)
   - Respond to users

---

## 🔒 Security Features

- **Session Management**: Uses localStorage for session persistence
- **Route Protection**: All user/admin pages check authentication
- **Separate Portals**: Complete separation between user and admin interfaces
- **Fixed Admin Credentials**: Prevents unauthorized admin access
- **Auto-redirect**: Unauthenticated users redirected to login

---

## 🧪 Testing the New System

### Test User Flow:

1. Open http://localhost:5000/
2. Sign up with:
   - Username: testuser
   - Mobile: 1234567890
   - Password: test123
3. Sign in with same credentials
4. Navigate through Detection, Evidence, Emergency
5. Test all features
6. Logout and sign in again

### Test Admin Flow:

1. Open http://localhost:5000/admin/login
2. Login with admin/admin123
3. Navigate through Dashboard, Chats, Reports
4. Test joining a user chat
5. Logout and login again

### Test Emergency Chat (User + Admin):

1. **User Side** (Browser 1):

   - Login as user
   - Go to Emergency
   - Start chat
   - Note the Chat ID

2. **Admin Side** (Browser 2/Incognito):
   - Login as admin
   - Go to Active Chats
   - Find the user's chat
   - Click "Join Chat"
   - Respond to user

---

## 📝 Important Notes

1. **No Functionality Changed**: All original features work exactly the same
2. **Authentication Added**: Only adds login/logout functionality
3. **In-Memory Storage**: User accounts stored in memory (restart clears them)
4. **Production Ready**: For production, use a real database and hash passwords
5. **Session Persistence**: Login persists across page refreshes
6. **Logout Required**: Click logout to clear session

---

## 🚀 Quick Start Commands

### Start Server:

```powershell
cd C:\Cybersafety
C:/Cybersafety/.venv/Scripts/python.exe app.py
```

### Test URLs:

- User Login: http://localhost:5000/login
- Admin Login: http://localhost:5000/admin/login
- User Dashboard: http://localhost:5000/user/dashboard
- Admin Dashboard: http://localhost:5000/admin/dashboard

---

## 🔧 Troubleshooting

**Can't login?**

- Make sure you signed up first
- Check username/password are correct
- Clear browser localStorage if issues persist

**Session lost?**

- Sessions stored in browser localStorage
- Clearing browser data will log you out
- Just login again

**Admin login not working?**

- Username must be exactly: `admin`
- Password must be exactly: `admin123`
- Case sensitive!

---

## 👥 Default Credentials

### Admin Account (Fixed):

- Username: `admin`
- Password: `admin123`

### User Accounts:

- Create your own via signup
- No default user accounts

---

**All original functionality preserved - just with authentication!** ✅
