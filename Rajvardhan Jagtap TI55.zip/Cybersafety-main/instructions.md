# AI-Powered Cyber Safety & Harassment Detection System with Explainable AI, Privacy Encryption, and Real-Time Emergency Chat Support for Women and Children (Seminar Prototype)

---

## Overview:

Build a simplified, privacy-first web application prototype that demonstrates an AI-powered cyber safety system for women and children.
The platform will detect online harassment in user-entered text using NLP, explain why the text was flagged (Explainable AI), encrypt evidence locally using AES-256, and allow real-time emergency chat between a user and a simulated cybersecurity department member with image upload support for evidence sharing.
This prototype will be **fully local**, not connected to any real social media platform.

---

## 🧠 Project Goals

1. Detect harassment automatically using AI (text input).
2. Explain why a message was flagged (Explainable AI).
3. Preserve user privacy via AES-256 encryption and local storage.
4. Enable real-time emergency chat between the user and a cybersecurity officer.
5. Allow users to upload encrypted images as harassment evidence.
6. Automatically generate a **detailed encrypted evidence report** for each incident.

---

## ⚙️ Features to Include

| Feature                              | Description                                                                                  |
| ------------------------------------ | -------------------------------------------------------------------------------------------- |
| **1️⃣ Text Harassment Detection**     | User inputs a message → NLP model detects if it's harassment or safe.                        |
| **2️⃣ Explainable AI (XAI)**          | Highlights offensive words and explains the reasoning behind AI decision.                    |
| **3️⃣ Evidence Report Generation**    | Automatically compiles incident details into a report and encrypts it locally using AES-256. |
| **4️⃣ Panic Button (Emergency Mode)** | Opens a real-time chat window with cybersecurity support.                                    |
| **5️⃣ Real-Time Chat**                | Two-way instant messaging between user and officer (Socket.IO).                              |
| **6️⃣ Image Upload in Chat**          | User can upload screenshots as encrypted evidence files.                                     |
| **7️⃣ Admin Panel (Officer View)**    | Separate page where an officer views chats and decrypts evidence.                            |
| **8️⃣ Local Privacy Preservation**    | All data is stored locally; no internet or external upload.                                  |

---

## 🧾 What the Encrypted Evidence Report Should Include

Each report should contain the following information before encryption:

| Section                                  | Description                                                    |
| ---------------------------------------- | -------------------------------------------------------------- |
| **1️⃣ Report ID**                         | Unique auto-generated ID (e.g., `RPT-00123`)                   |
| **2️⃣ Date & Time**                       | Timestamp of when the harassment was detected                  |
| **3️⃣ User Info**                         | User name (optional), device ID, or "Anonymous User"           |
| **4️⃣ Input Text**                        | The message or comment analyzed                                |
| **5️⃣ AI Detection Result**               | "Harassment Detected" / "Safe Message"                         |
| **6️⃣ Confidence Score**                  | AI model's confidence percentage (e.g., 93%)                   |
| **7️⃣ Explainable AI Reason**             | Words or phrases flagged and brief explanation                 |
| **8️⃣ Uploaded Evidence**                 | List of uploaded image filenames (encrypted)                   |
| **9️⃣ Chat Reference ID (if applicable)** | ID linking to emergency chat session                           |
| **🔟 Encryption Details**                | Type of encryption used (AES-256) + local storage confirmation |

When the user clicks **"Save Report"**, this data will be:

1. Compiled into a structured JSON or text file.
2. Encrypted using AES-256.
3. Saved locally in a `/reports` folder.

Example report (before encryption):

```json
{
  "report_id": "RPT-2025-001",
  "datetime": "2025-10-10 14:32:55",
  "user": "Anonymous",
  "input_text": "You're such a loser",
  "result": "Harassment Detected",
  "confidence": "94%",
  "explanation": "Word 'loser' identified as abusive.",
  "uploaded_evidence": ["image1.enc"],
  "chat_id": "CHAT-1001",
  "encryption": "AES-256 | Stored Locally"
}
```

---

## 🖥️ User Interface (Frontend)

Create a clean, minimal web UI with the following sections:

1. **Home/Dashboard**

   - Brief intro and system overview.

2. **Detection Page**

   - Text input box.
   - "Analyze" button → Show detection result.
   - Explainable AI highlighting and reasoning.

3. **Evidence Page**

   - "Save Report" button → Generate and encrypt report.
   - Message: "Encrypted Report Saved Successfully."

4. **Emergency Help Page**

   - "Panic Button" → Opens chat window.
   - Real-time messaging between user and officer.
   - Option to upload encrypted images.

5. **Admin Panel**
   - Officer login.
   - Displays list of user chats and reports.
   - Decrypts evidence files.

---

## 🧰 Suggested Tech Stack

| Layer              | Technology                                                                            |
| ------------------ | ------------------------------------------------------------------------------------- |
| **Frontend**       | HTML, CSS, JavaScript (or React.js)                                                   |
| **Backend**        | Python (Flask + Flask-SocketIO) or Node.js (Express + Socket.IO)                      |
| **AI Model**       | Pre-trained text classification model (e.g., "toxic comment" model from Hugging Face) |
| **Explainable AI** | Keyword highlighting or SHAP/LIME (for text)                                          |
| **Encryption**     | AES-256 using `cryptography` (Python) or `crypto-js` (JavaScript)                     |
| **Database**       | SQLite (for chat & reports) or JSON files                                             |
| **Storage**        | Local folders: `/uploads` for encrypted images, `/reports` for encrypted reports      |
| **Chat**           | Socket.IO for real-time messaging                                                     |
| **Image Upload**   | Flask `request.files` or Node.js `Multer`                                             |

---

## 🧱 Folder Structure

```
cybersafety_prototype/
│
├── app.py / server.js               # Backend logic
├── templates/
│   ├── index.html                   # Dashboard
│   ├── detect.html                  # Detection UI
│   ├── evidence.html                # Report generation
│   ├── emergency.html               # Chat system
│   └── admin.html                   # Officer panel
│
├── static/
│   ├── style.css
│   └── script.js
│
├── model/
│   └── harassment_model.pkl         # Optional AI model
│
├── uploads/
│   └── image1.enc                   # Encrypted evidence
│
├── reports/
│   └── report_001.enc               # Encrypted report
│
└── db.sqlite3                       # Local database
```

---

## ⚡ Step-by-Step Implementation Plan

### **Phase 1 – UI Design**

- Build HTML pages for Home, Detection, Evidence, Emergency, and Admin.
- Add navigation bar and consistent styling.

### **Phase 2 – AI Harassment Detection**

- Integrate a pre-trained NLP model (toxic comment classifier).
- Input → Predict → Display result.
- Show Explainable AI highlights and reason text.

### **Phase 3 – Evidence Report System**

- After detection, allow saving an encrypted report.
- Collect report details (text, result, confidence, explanation, timestamp).
- Encrypt report using AES-256 and store locally.

### **Phase 4 – Emergency Panic & Chat**

- "Panic Button" opens chat window.
- Use Socket.IO for real-time two-way messaging.
- Chat logs stored locally with timestamp and chat ID.

### **Phase 5 – Image Upload**

- Allow file upload from user side.
- Encrypt image using AES-256 before saving in `/uploads/`.
- Display confirmation message for successful upload.

### **Phase 6 – Admin Panel**

- Officer logs in to view ongoing chats and reports.
- Decrypt and read stored evidence when needed.

### **Phase 7 – Privacy & Simulation**

- Show messages like "All processing done locally" and "No internet connection required."
- Ensure the entire system runs offline.

---

## 🔍 Example User Flow (For Demo)

1. User inputs "You're a stupid loser."
   → Output: "Harassment Detected"
   → Explanation: "Contains abusive term 'loser'."
2. Clicks "Save Report" → Encrypted JSON file saved locally.
3. Clicks "Panic Button" → Chat window opens.
4. User types: "Someone is threatening me."
   → Officer replies from Admin Panel: "Please upload screenshots."
5. User uploads image → System encrypts and stores as evidence.
6. Report and chat linked under same chat ID.
7. Show final message: "Your data is secure. All files are stored locally."

---

## 🔒 Privacy Demonstration in Seminar

Explain to your audience:

- "All AI and encryption runs locally, ensuring full privacy."
- "AES-256 ensures data cannot be accessed by anyone else."
- "The chat system and evidence handling simulate secure emergency workflows."

---

## 🎨 Optional UI Enhancements

- Color-coded result cards (green = safe, red = harassment).
- Dashboard summary:
  - Total Reports Generated
  - Total Chats Started
- Add "Download Encrypted Report" option.
- Add "Decrypt (Officer Only)" feature in Admin panel.

---

## 🧾 Final Description for Presentation

> This seminar prototype demonstrates how Artificial Intelligence, Explainable AI, and privacy-first encryption can work together to create a cyber safety system for women and children. It automatically detects harassment in text, explains why it was flagged, stores encrypted evidence locally, and provides an emergency chat channel to communicate with cybersecurity officers in real time — including image uploads as evidence. All processing is local, ensuring full privacy protection.

---

## **Deliverables Expected**

After executing this prompt, the output system should include:

- Fully functional frontend + backend
- Real-time chat module
- AI harassment detection system
- Explainable AI reasoning display
- AES-256 encrypted report generation
- Image upload + encryption
- Admin panel for officers
- Offline and privacy-first workflow
- Ready-to-run seminar prototype
