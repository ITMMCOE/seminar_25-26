import streamlit as st
import os
from langchain_google_genai import GoogleGenerativeAIEmbeddings, ChatGoogleGenerativeAI
from langchain.vectorstores import FAISS
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationBufferMemory
from dotenv import load_dotenv
import google.generativeai as genai

# --- Configuration and Setup ---
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
FAISS_INDEX_PATH = "faiss_index"

# --- Caching Functions to improve performance ---

@st.cache_resource
def load_vector_store():
    """Loads the FAISS index from disk. Cached for performance."""
    if not os.path.exists(FAISS_INDEX_PATH):
        st.error(f"Index not found. Please run the data ingestion script first.")
        st.stop()
    
    print("Loading vector store...")
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001")
    db = FAISS.load_local(FAISS_INDEX_PATH, embeddings, allow_dangerous_deserialization=True)
    print("Vector store loaded successfully.")
    return db

def create_conversational_chain(db):
    """Creates and returns the conversational retrieval chain."""
    
    # 1. Define the LLM for the chat model
    llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash", temperature=0.2, convert_system_message_to_human=True)
    
    # 2. Set up conversation memory
    # This memory object will store the chat history
    memory = ConversationBufferMemory(
        memory_key='chat_history', 
        return_messages=True
    )
    
    # 3. Create the ConversationalRetrievalChain
    # This chain is specifically designed for Q&A with a chat history
    chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever=db.as_retriever(),
        memory=memory
    )
    return chain

def main():
    """Main function to run the Streamlit app."""
    st.set_page_config(page_title="Supreme Court RAG", page_icon="⚖️")
    st.header("⚖️ Supreme Court Judgment Chatbot")

    # --- Load Resources ---
    db = load_vector_store()
    
    # We create the chain inside main now, as it holds session-specific memory
    chain = create_conversational_chain(db)

    # --- Initialize Chat History in Session State ---
    if "messages" not in st.session_state:
        st.session_state.messages = [{"role": "assistant", "content": "How can I help you with the legal documents today?"}]

    # --- Display Prior Chat Messages ---
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # --- Handle New User Input ---
    if prompt := st.chat_input("Ask a follow-up question..."):
        # Add user message to session state and display it
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        # Display assistant's "thinking..." message
        with st.chat_message("assistant"):
            message_placeholder = st.empty()
            message_placeholder.markdown("Thinking...")
            
            # Get the history from session state
            chat_history = [
                (msg["content"]) for msg in st.session_state.messages if msg["role"] == 'user'
            ]

            # Invoke the chain to get a response
            result = chain({"question": prompt, "chat_history": chat_history})
            response = result["answer"]
            
            # Display the actual response
            message_placeholder.markdown(response)
        
        # Add assistant's response to session state
        st.session_state.messages.append({"role": "assistant", "content": response})

if __name__ == "__main__":
    main()