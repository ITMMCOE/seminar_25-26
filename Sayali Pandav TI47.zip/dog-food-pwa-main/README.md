
# TailTreat 

**TailTreat** is a Progressive Web App (PWA) that helps you check if a food item is safe for your dog.  
It uses the USDA FoodData Central API for accurate food information and even works offline!  

## 🌐 Live Demo
Check it out here: [TailTreat](https://tailtreat.netlify.app)

## ✨ Features
- Search for any food item (dog food or human food)  
- Displays safety status with clear warnings (safe ✅ or unsafe ⚠️)  
- Offline support as a Progressive Web App (PWA)  
- Powered by USDA FoodData Central API for accurate food information  
  

## 🛠️ Tech Stack
- React  
- Vite  
- Progressive Web App (PWA)  
- USDA FoodData Central API  
- CSS & SVG  

## 🚀 Installation

### Clone the repository

git clone https://github.com/sayalipandav305/dog-food-pwa.git

### Navigate into the project folder


cd dog-food-pwa


### Install dependencies


npm install


### Run the project locally


npm run dev

---

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

