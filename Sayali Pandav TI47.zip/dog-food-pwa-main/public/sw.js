const CACHE_NAME = "dogsafe-cache-v1";
const urlsToCache = [
  "/index.html",
  "/manifest.json",
  "/favicon.ico",        // add if you have one
  "/vite.svg",           // your app icon; must be in /public
  "/robots.txt",         // optional
];

// Install service worker and cache essential files
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(urlsToCache))
  );
  self.skipWaiting();
});

// Activate service worker and clean old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((key) => key !== CACHE_NAME)
          .map((key) => caches.delete(key))
      )
    )
  );
  self.clients.claim();
});

// Fetch handler: try network first, fallback to cache
self.addEventListener("fetch", (event) => {
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        // Optionally cache new requests dynamically
        return response;
      })
      .catch(() =>
        caches.match(event.request).then((cachedResponse) => {
          if (cachedResponse) return cachedResponse;

          // SPA fallback: serve index.html for navigation requests
          if (event.request.mode === "navigate") {
            return caches.match("/index.html");
          }
        })
      )
  );
});
