import React, { useState } from "react";

const searchFoodOnline = async (query) => {
  const API_KEY = "sZHeLbreFZOWCjmPGnfdbNLvZd5DvHNXTZ7PH8Sy";
  const url = `https://api.nal.usda.gov/fdc/v1/foods/search?query=${encodeURIComponent(
    query
  )}&pageSize=1&api_key=${API_KEY}`;

  const unsafeFoods = [
    "chocolate", "grape", "raisin", "onion", "garlic", "avocado",
    "macadamia", "xylitol", "caffeine", "alcohol", "coffee",
    "cherry", "ice cream", "palm"
  ];

  const pluralMap = {
    cherries: "cherry",
    grapes: "grape",
    raisins: "raisin",
    onions: "onion",
    garlics: "garlic",
    avocadoes: "avocado",
  };

  const normalizeWord = (word) => pluralMap[word] || word;

  try {
    const response = await fetch(url);
    const data = await response.json();

    if (data.foods && data.foods.length > 0) {
      const food = data.foods[0];
      const combinedText = [food.description || "", food.brandOwner || ""]
        .join(" ")
        .toLowerCase();

      const textWords = combinedText
        .split(/\W+/)
        .map(normalizeWord)
        .filter(Boolean);

      const foundUnsafe = unsafeFoods.filter((uf) => textWords.includes(uf));

      let status = "✅ Likely safe to feed! 🎉";
      if (foundUnsafe.length > 0) {
        status = foundUnsafe.includes("cherry")
          ? "⚠️ Unsafe for dogs! Cherry pits and stems are toxic."
          : `⚠️ Unsafe! Contains: ${foundUnsafe.join(", ")}`;
      }

      return {
        found: true,
        data: {
          status,
          unsafe: foundUnsafe.length > 0,
          brand: food.brandOwner || "Unknown Brand",
          name: food.description || query,
        },
      };
    }
    return { found: false, data: null };
  } catch (err) {
    console.error("USDA fetch error:", err);
    return { found: false, data: null };
  }
};

export default function App() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    setResult(null);
    const res = await searchFoodOnline(query);
    setResult(res);
    setLoading(false);
  };

  return (
    <div className="tailtreat-bg">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Fredoka+One&family=Montserrat:wght@500&display=swap');
        html, body {
          margin: 0;
          padding: 0;
          height: 100%;
        }

        .tailtreat-bg {
          min-height: 100vh;
          width: 100vw;
          background: linear-gradient(135deg, #FFF8E1 0%, #FFE0B2 100%);
          font-family: 'Montserrat', Arial, sans-serif;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: flex-start;
          padding: 20px;
          box-sizing: border-box;
        }

        .tailtreat-header {
          display: flex;
          align-items: center;
          justify-content: center;
          margin-top: 10px;
        }

        .tailtreat-logo {
          font-size: 2.5rem;
          margin-right: 10px;
        }

        .tailtreat-brand {
          font-size: clamp(1.5rem, 4vw, 2.2rem);
          font-family: 'Fredoka One', cursive;
          color: #FFA400;
          font-weight: bold;
        }

        .tailtreat-main {
          width: 100%;
          max-width: 560px;
          background: #fff;
          border-radius: 26px;
          margin-top: 30px;
          box-shadow: 0 0 44px 0 #ffa40018;
          padding: 40px 25px;
          text-align: center;
        }

        .tailtreat-title {
          color: #26bbc1;
          font-size: clamp(1.4rem, 5vw, 2.1rem);
          font-weight: 900;
          margin-bottom: 10px;
        }

        .tailtreat-desc {
          font-size: clamp(0.9rem, 3.5vw, 1.1rem);
          color: #333;
          margin-bottom: 28px;
        }

        .tailtreat-form {
          display: flex;
          flex-direction: row;
          justify-content: center;
          align-items: center;
          gap: 10px;
          margin-bottom: 28px;
        }

        @media (max-width: 600px) {
          .tailtreat-form {
            flex-direction: column;
          }
          .tailtreat-btn {
            width: 100%;
          }
          .tailtreat-input {
            width: 100%;
          }
        }

        .tailtreat-input {
          flex: 1;
          padding: 14px 16px;
          border-radius: 18px;
          border: 2px solid #ffe5b4;
          font-size: 1.1rem;
          outline: none;
          transition: border-color 0.3s;
        }

        .tailtreat-input:focus {
          border-color: #ffa400;
        }

        .tailtreat-btn {
          background: #ffa400;
          color: #fff;
          border: none;
          border-radius: 15px;
          padding: 14px 27px;
          font-size: 1rem;
          font-weight: 700;
          cursor: pointer;
          box-shadow: 0 6px 14px #ffa40023;
          transition: background 0.2s, box-shadow 0.2s;
        }

        .tailtreat-btn:hover:enabled {
          background: #ff7f00;
          box-shadow: 0 10px 25px #ffce7b36;
        }

        .tailtreat-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .tailtreat-result-box {
          margin-top: 18px;
          border-radius: 16px;
          padding: 30px 20px 16px 20px;
          font-size: 1.07rem;
          border: 2px dashed #ffd580;
          background: #fffbe7;
          color: #5d4b00;
          word-break: break-word;
        }

        .tailtreat-safe {
          border: 2px dashed #86efac;
          background: #ecfdf5;
          color: #065f46;
        }

        .tailtreat-alert {
          border: 2px dashed #fca5a5;
          background: #fff1f2;
          color: #e11d48;
        }

        .tailtreat-result-title {
          font-size: 1.1rem;
          font-weight: bold;
          margin-bottom: 7px;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 9px;
          text-align: center;
        }

        .tailtreat-highlight {
          color: #f68b00;
          font-weight: bold;
        }
      `}</style>

      <div className="tailtreat-header">
        <span className="tailtreat-logo">🐾</span>
        <span className="tailtreat-brand">TailTreat</span>
      </div>

      <div className="tailtreat-main">
        <h1 className="tailtreat-title">Is it paw-sitively safe for your pup?</h1>
        <p className="tailtreat-desc">Type in a dog food and we'll sniff out the details!</p>

        <div className="tailtreat-form">
          <input
            className="tailtreat-input"
            type="text"
            placeholder=""
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            disabled={loading}
          />
          <button
            className="tailtreat-btn"
            onClick={handleSearch}
            disabled={loading}
          >
            {loading ? "Fetching..." : "Fetch Results"}
          </button>
        </div>

        {result && (
          <div
            className={`tailtreat-result-box ${
              result.found
                ? result.data?.unsafe
                  ? "tailtreat-alert"
                  : "tailtreat-safe"
                : ""
            }`}
          >
            {result.found ? (
              <>
                <div className="tailtreat-result-title">
                  {result.data.unsafe ? "⚠️ Paw-se for a Moment!" : "✅ Dog food looks safe!"}
                </div>
                <div>
                  {result.data.unsafe ? (
                    <>
                      Our checks indicate that <span className="tailtreat-highlight">{result.data.name}</span> has some concerns.<br />
                      {result.data.status}<br />Please consult your vet.
                    </>
                  ) : (
                    <>
                      <span className="tailtreat-highlight">{result.data.name}</span> appears safe.<br />
                      {result.data.status}
                    </>
                  )}
                </div>
              </>
            ) : (
              <div className="tailtreat-result-title">🤔 No result found. Try another food.</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
