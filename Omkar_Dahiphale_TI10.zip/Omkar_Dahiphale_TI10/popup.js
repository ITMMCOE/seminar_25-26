// popup.js - Enhanced with beautiful UI interactions and robust error handling
(() => {
  'use strict';
  
  const recommendButton = document.getElementById('recommend');
  const status = document.getElementById('status');
  const results = document.getElementById('results');
  
  // Utility functions for UI updates
  function updateStatus(message, type = 'loading') {
    status.textContent = message;
    status.className = type;
    
    if (type === 'loading') {
      status.innerHTML = message + '<span class="loading-dots"></span>';
    }
  }
  
  function setButtonState(isLoading = false) {
    if (isLoading) {
      recommendButton.classList.add('loading');
      recommendButton.disabled = true;
      recommendButton.innerHTML = '<span class="icon-brain"></span> Processing...';
    } else {
      recommendButton.classList.remove('loading');
      recommendButton.disabled = false;
      recommendButton.innerHTML = '<span class="icon-brain"></span> Get Learning Prerequisites';
    }
  }
  
  function createResultCard(type, data, icon) {
    const card = document.createElement('div');
    card.className = 'result-card';
    
    const label = document.createElement('div');
    label.className = 'result-label';
    label.innerHTML = `<span class="${icon}"></span> ${type}`;
    
    const content = document.createElement('div');
    content.className = 'result-content';
    
    if (data && data.url) {
      const link = document.createElement('a');
      link.href = data.url;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      link.textContent = data.title || 'View Resource';
      content.appendChild(link);
      
      if (data.snippet) {
        const snippet = document.createElement('div');
        snippet.className = 'result-snippet';
        snippet.textContent = data.snippet;
        content.appendChild(snippet);
      }
    } else {
      content.innerHTML = '<span style="color: #a0aec0; font-style: italic;">No resource found</span>';
    }
    
    card.appendChild(label);
    card.appendChild(content);
    return card;
  }
  
  function showEmptyState(message) {
    results.innerHTML = `
      <div class="empty-state">
        <div class="icon">🤔</div>
        <p>${message}</p>
      </div>
    `;
  }
  
  function displayResults(recommendations, problemData) {
    results.innerHTML = '';
    
    // Add problem info header
    const problemHeader = document.createElement('div');
    problemHeader.style.cssText = 'background: #edf2f7; padding: 12px; border-radius: 8px; margin-bottom: 16px; font-size: 13px;';
    problemHeader.innerHTML = `
      <strong>${problemData.title || 'Current Problem'}</strong><br>
      <span style="color: #718096;">Difficulty: ${problemData.difficulty || 'Unknown'} | Topics: ${(problemData.topics || []).join(', ')}</span>
    `;
    results.appendChild(problemHeader);
    
    // Add recommendation cards
    const { video, article, practice } = recommendations;
    
    // Create cards with staggered animation
    const cards = [
      { type: 'Prerequisite Video Tutorial', data: video, icon: 'icon-video' },
      { type: 'Fundamental Concepts Article', data: article, icon: 'icon-article' },
      { type: 'Practice Problems', data: practice, icon: 'icon-practice' }
    ];
    
    cards.forEach((cardData, index) => {
      setTimeout(() => {
        const card = createResultCard(cardData.type, cardData.data, cardData.icon);
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        results.appendChild(card);
        
        // Animate in
        setTimeout(() => {
          card.style.transition = 'all 0.4s ease';
          card.style.opacity = '1';
          card.style.transform = 'translateY(0)';
        }, 50);
      }, index * 150);
    });
    
    // Add a tip at the bottom
    setTimeout(() => {
      const tip = document.createElement('div');
      tip.style.cssText = 'text-align: center; margin-top: 20px; padding: 12px; background: rgba(102, 126, 234, 0.1); border-radius: 6px; font-size: 12px; color: #667eea;';
      tip.innerHTML = '💡 <strong>Tip:</strong> Study these prerequisites before attempting the problem';
      results.appendChild(tip);
    }, 600);
  }
  
  // Main click handler
  recommendButton.addEventListener('click', async () => {
    updateStatus('Analyzing current problem', 'loading');
    setButtonState(true);
    results.innerHTML = '';
    
    try {
      // Get current tab
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      
      if (!tab || !tab.url) {
        throw new Error('Cannot access current tab');
      }
      
      // Check if on LeetCode
      if (!tab.url.includes('leetcode.com')) {
        throw new Error('Please navigate to a LeetCode problem page first');
      }
      
      updateStatus('Reading problem details', 'loading');
      
      // Get problem info from content script
      const problemData = await chrome.tabs.sendMessage(tab.id, { type: 'getProblem' });
      
      if (!problemData || !problemData.success) {
        const errorMsg = problemData?.error || 'Failed to read problem data';
        throw new Error(errorMsg);
      }
      
      updateStatus('AI analyzing prerequisites needed', 'loading');
      
      // Get recommendations from background
      const recommendations = await chrome.runtime.sendMessage({
        type: 'getRecommendations',
        data: problemData
      });
      
      if (!recommendations || !recommendations.success) {
        const errorMsg = recommendations?.error || 'Failed to get recommendations';
        throw new Error(errorMsg);
      }
      
      updateStatus('✅ Prerequisites found!', 'success');
      setButtonState(false);
      
      // Display results with animation
      displayResults(recommendations, problemData);
      
    } catch (err) {
      console.error('Popup error:', err);
      updateStatus(`❌ ${err.message}`, 'error');
      setButtonState(false);
      
      // Show helpful error message
      const isLeetCodePage = window.location?.href?.includes('leetcode.com');
      const errorMessage = isLeetCodePage 
        ? 'Make sure you\'re on a specific problem page (e.g., /problems/two-sum/)'
        : 'Please navigate to a LeetCode problem page and try again';
        
      showEmptyState(errorMessage);
    }
  });
  
  // Initialize UI
  document.addEventListener('DOMContentLoaded', () => {
    updateStatus('Ready to analyze prerequisites', '');
    
    // Add keyboard shortcut (Enter key)
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && !recommendButton.disabled) {
        recommendButton.click();
      }
    });
    
    // Auto-focus button for accessibility
    recommendButton.focus();
  });
  
  // Handle extension errors
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'error') {
      updateStatus(`❌ ${message.error}`, 'error');
      setButtonState(false);
    }
  });
  
  console.log('LC Prerequisites Tutor popup loaded');
})();
