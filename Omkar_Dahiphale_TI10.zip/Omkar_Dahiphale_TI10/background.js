const apiKey = process.env.GROQ_API_KEY;
const TAVILY_KEY =  process.env.TAVILY_API_KEY;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type !== "getRecommendations") return;
  
  const { title, difficulty, topics } = msg.data;
  
  // Enhanced prompt for PREREQUISITE recommendations
  const prompt = `You are an expert coding tutor. For the LeetCode problem "${title}" (${difficulty} difficulty) with topics [${topics.join(", ")}], I need to know what concepts someone should learn BEFORE attempting this problem.

Create 3 search queries for PREREQUISITE learning:
1. video: A tutorial for the fundamental concept/algorithm needed (not the specific problem)
2. article: An explanation of the core theory/data structure required  
3. practice: Easier problems that build up the skills needed for this problem

Focus on PREREQUISITES and FUNDAMENTALS, not the actual problem solution.

Return only JSON:
{
  "video": "search query for prerequisite concept tutorial",
  "article": "search query for fundamental theory explanation", 
  "practice": "search query for easier buildup problems"
}`;

  fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${GROQ_KEY}`
    },
    body: JSON.stringify({
      model: "llama-3.3-70b-versatile",
      messages: [
        { role: "system", content: "You are a coding tutor focused on prerequisite learning. Return only valid JSON." },
        { role: "user", content: prompt }
      ],
      temperature: 0.2
    })
  })
  .then(res => res.json())
  .then(llmData => {
    console.log("Groq response:", llmData); // Debug log
    
    if (!llmData.choices || !llmData.choices[0]) {
      throw new Error("Invalid Groq response");
    }
    
    const content = llmData.choices[0].message.content;
    let queries;
    
    try {
      // Clean up the response if it has markdown formatting
      const cleanContent = content.replace(/``````/g, '').trim();
      queries = JSON.parse(cleanContent);
    } catch (e) {
      console.log("JSON parse failed, using fallback:", e);
      // Intelligent fallback based on main topic
      const mainTopic = topics[0] || "arrays";
      queries = {
        video: `${mainTopic} fundamentals tutorial for beginners`,
        article: `${mainTopic} data structure basics explanation`,
        practice: `${mainTopic} easy problems for practice`
      };
    }

    // Enhanced searches with better targeting
    const searches = [
      searchTavily(`${queries.video} (site:youtube.com/c/AbdulBari OR site:youtube.com/c/TakeUforward OR site:youtube.com/c/NeetCode)`),
      searchTavily(`${queries.article} (site:geeksforgeeks.org OR site:programiz.com OR site:tutorialspoint.com)`),
      searchTavily(`${queries.practice} (site:leetcode.com/problemset OR site:hackerrank.com OR site:codingbat.com)`)
    ];

    return Promise.all(searches);
  })
  .then(([video, article, practice]) => {
    sendResponse({
      success: true,
      video: video,
      article: article,
      practice: practice
    });
  })
  .catch(err => {
    console.error("Background error:", err);
    sendResponse({ 
      success: false, 
      error: err.message 
    });
  });

  return true; // async response
});

function searchTavily(query) {
  console.log("Searching Tavily for:", query);
  
  return fetch("https://api.tavily.com/search", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      api_key: TAVILY_KEY,
      query: query,
      search_depth: "basic",
      max_results: 3
    })
  })
  .then(res => {
    if (!res.ok) {
      throw new Error(`Tavily API error: ${res.status}`);
    }
    return res.json();
  })
  .then(data => {
    console.log("Tavily response:", data);
    
    if (!data.results || data.results.length === 0) {
      return null;
    }
    
    // Get the best result (first one is usually highest ranked)
    const result = data.results[0];
    return { 
      title: result.title, 
      url: result.url,
      snippet: result.content ? result.content.substring(0, 150) + "..." : ""
    };
  })
  .catch(err => {
    console.error("Tavily search error:", err);
    return null;
  });
}

// Optional: Add a simple cache to avoid repeated API calls
const searchCache = new Map();

function getCachedSearch(query) {
  if (searchCache.has(query)) {
    return Promise.resolve(searchCache.get(query));
  }
  
  return searchTavily(query).then(result => {
    if (result) {
      searchCache.set(query, result);
    }
    return result;
  });
}
