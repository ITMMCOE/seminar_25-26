// content.js - Enhanced with better error handling and debugging
(() => {
  'use strict';
  
  // Debug logging function
  function debugLog(message, data = null) {
    console.log(`[LC Recommender] ${message}`, data || '');
  }
  
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== "getProblem") return;
    
    debugLog("Getting problem data from LeetCode page");
    
    // Get problem slug from URL - more robust method
    function getProblemSlug() {
      const pathname = location.pathname;
      debugLog("Current pathname:", pathname);
      
      // Handle different URL formats:
      // /problems/two-sum/ or /problems/two-sum/description/ or /problems/two-sum/solutions/
      const match = pathname.match(/\/problems\/([^\/]+)/);
      if (match && match[1]) {
        return match[1];
      }
      
      // Fallback to old method
      const parts = pathname.split("/");
      const problemIndex = parts.indexOf("problems");
      return problemIndex >= 0 && parts[problemIndex + 1] ? parts[problemIndex + 1] : null;
    }
    
    const problemSlug = getProblemSlug();
    
    if (!problemSlug) {
      debugLog("Error: Not on a problem page");
      sendResponse({ 
        success: false, 
        error: "Please navigate to a LeetCode problem page (e.g., /problems/two-sum/)" 
      });
      return;
    }
    
    debugLog("Found problem slug:", problemSlug);
    
    // Enhanced GraphQL query with more fields
    const graphqlQuery = {
      query: `query getProblemDetails($titleSlug: String!) {
        question(titleSlug: $titleSlug) {
          title
          difficulty
          topicTags {
            name
            slug
          }
          content
          hints
          similarQuestions
        }
      }`,
      variables: { titleSlug: problemSlug }
    };
    
    debugLog("Making GraphQL request for:", problemSlug);
    
    // Make the GraphQL request
    fetch("/graphql", {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "User-Agent": navigator.userAgent,
        "Referer": location.href
      },
      credentials: "same-origin", // Important for auth
      body: JSON.stringify(graphqlQuery)
    })
    .then(res => {
      debugLog("GraphQL response status:", res.status);
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      }
      return res.json();
    })
    .then(data => {
      debugLog("GraphQL response data:", data);
      
      if (data.errors) {
        throw new Error(`GraphQL errors: ${JSON.stringify(data.errors)}`);
      }
      
      const question = data?.data?.question;
      if (!question) {
        throw new Error("Question data not found in response");
      }
      
      // Format the response
      const problemData = {
        success: true,
        title: question.title,
        difficulty: question.difficulty,
        topics: question.topicTags.map(tag => tag.name),
        topicSlugs: question.topicTags.map(tag => tag.slug),
        slug: problemSlug,
        hints: question.hints || [],
        url: location.href
      };
      
      debugLog("Sending problem data:", problemData);
      sendResponse(problemData);
    })
    .catch(err => {
      debugLog("Error fetching problem data:", err.message);
      
      // Fallback: Try to extract info from DOM if GraphQL fails
      const fallbackData = extractFromDOM(problemSlug);
      if (fallbackData.title) {
        debugLog("Using fallback DOM extraction");
        sendResponse(fallbackData);
      } else {
        sendResponse({ 
          success: false, 
          error: `Failed to get problem data: ${err.message}` 
        });
      }
    });
    
    return true; // Keep message channel open for async response
  });
  
  // Fallback function to extract data from DOM if GraphQL fails
  function extractFromDOM(slug) {
    debugLog("Attempting DOM extraction fallback");
    
    try {
      // Try to get title from various possible selectors
      const titleSelectors = [
        '[data-cy="question-title"]',
        '.text-title-large',
        '.css-v3d350',
        'h1'
      ];
      
      let title = '';
      for (const selector of titleSelectors) {
        const titleEl = document.querySelector(selector);
        if (titleEl && titleEl.textContent.trim()) {
          title = titleEl.textContent.trim();
          break;
        }
      }
      
      // Try to get difficulty
      const difficultySelectors = [
        '[diff="Easy"]', '[diff="Medium"]', '[diff="Hard"]',
        '.text-olive', '.text-yellow', '.text-pink'
      ];
      
      let difficulty = 'Medium'; // Default fallback
      for (const selector of difficultySelectors) {
        const diffEl = document.querySelector(selector);
        if (diffEl) {
          difficulty = diffEl.textContent.trim() || diffEl.getAttribute('diff') || difficulty;
          break;
        }
      }
      
      // Extract topics from tags (if visible)
      const topics = [];
      const tagElements = document.querySelectorAll('[class*="tag"], [class*="topic"]');
      tagElements.forEach(tag => {
        const text = tag.textContent.trim();
        if (text && text.length < 30) { // Reasonable topic name length
          topics.push(text);
        }
      });
      
      return {
        success: true,
        title: title || `Problem: ${slug}`,
        difficulty: difficulty,
        topics: topics.length > 0 ? topics : ['arrays'], // Default topic
        slug: slug,
        url: location.href,
        source: 'dom-fallback'
      };
    } catch (err) {
      debugLog("DOM extraction failed:", err.message);
      return { success: false, error: "DOM extraction failed" };
    }
  }
  
  // Optional: Listen for URL changes in SPA
  let currentUrl = location.href;
  const observer = new MutationObserver(() => {
    if (location.href !== currentUrl) {
      currentUrl = location.href;
      debugLog("URL changed to:", currentUrl);
    }
  });
  
  // Start observing for changes
  observer.observe(document, { subtree: true, childList: true });
  
  debugLog("Content script loaded successfully");
})();
