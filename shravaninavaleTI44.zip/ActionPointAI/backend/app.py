# --- ActionPoint AI Backend: Flask Server ---
# This server handles audio transcription (Vosk), summarization (Gemini API), and email sending (SMTP).

import os
import json
import subprocess
import wave
import time
import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# External libraries
from flask import Flask, request, jsonify
from flask_cors import CORS
from vosk import Model, KaldiRecognizer, SetLogLevel
from dotenv import load_dotenv

# --- Configuration ---
# Load environment variables from .env file
load_dotenv()

# Suppress Vosk logs for a cleaner console
SetLogLevel(-1)

# IMPORTANT: Use 'r' before the string for Windows paths to avoid SyntaxError
MODEL_PATH = r"C:\Users\Shravani\OneDrive\Desktop\ActionPointAI\backend\vosk-model-en-us-0.22\vosk-model-en-us-0.22"

# Check if model path is correctly configured
if not os.path.exists(MODEL_PATH):
    print(f"ERROR: Vosk model not found at '{MODEL_PATH}'")
    exit(1)
try:
    VOSK_MODEL = Model(MODEL_PATH)
    print(f"Vosk model loaded successfully from {MODEL_PATH}")
except Exception as e:
    print(f"Error loading Vosk model: {e}. Transcription will not work.")
    VOSK_MODEL = None


# --- Environment Variable Retrieval ---

def get_gemini_api_key():
    """Retrieves the Gemini API key from environment variables."""
    # Note: If running on Canvas, __api_key might be available. Otherwise, use .env
    return os.getenv("GEMINI_API_KEY", "")

def get_email_credentials():
    """Retrieves email credentials from environment variables."""
    return (
        os.getenv("SENDER_EMAIL"),
        os.getenv("SENDER_PASSWORD"),  # This should be your App Password
        os.getenv("SMTP_SERVER", "smtp.gmail.com"),
        int(os.getenv("SMTP_PORT", 587))
    )

# --- Flask Setup ---
app = Flask(__name__)
# Enable CORS for frontend communication (React runs on a different port)
CORS(app) 
API_KEY = get_gemini_api_key()

# --- Gemini API Call Functions ---

def call_gemini_api_text_only(prompt, model_name="gemini-2.5-flash-preview-05-20", tools=None, system_instruction=None):
    """
    Handles a simple POST request to the Gemini API, expecting only text output.
    Used for general debugging or simple calls (not used for structured output).
    """
    if not API_KEY:
        print("Gemini API Key is missing. Check your .env file.")
        return None, "API Key Missing", 500

    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model_name}:generateContent?key={API_KEY}"
    
    payload = {
        "contents": [{"parts": [{"text": prompt}]}],
    }
    
    if tools:
        payload["tools"] = tools
    
    if system_instruction:
        payload["systemInstruction"] = {"parts": [{"text": system_instruction}]}

    headers = {'Content-Type': 'application/json'}

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status() 
        
        result = response.json()
        
        # Extract text from the response structure
        text = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '').strip()
        if text:
            return text, None, 200
        else:
            return None, "Gemini API returned empty text.", 500

    except requests.exceptions.RequestException as e:
        error_message = f"Gemini API Request Error: {e}"
        # print(f"Raw API response content: {response.text}") # For detailed debugging
        return None, error_message, response.status_code if 'response' in locals() else 500


def get_summary_and_actions(transcript):
    """Uses Gemini to generate a summary and action items from a transcript using structured JSON output."""
    
    system_prompt = (
        "You are an expert meeting minute taker and analyst. "
        "Your task is to analyze the provided meeting transcript and extract a concise summary (1-2 paragraphs) "
        "and a list of all actionable tasks. Format the response ONLY as a JSON object."
    )
    
    user_prompt = f"Meeting Transcript:\n---\n{transcript}\n---\nAnalyze the transcript above and provide the summary and action items."

    # Define the required JSON structure (responseSchema)
    json_schema = {
        "type": "OBJECT",
        "properties": {
            "summary": {"type": "STRING", "description": "A concise 1-2 paragraph summary of the meeting."},
            "action_items": {
                "type": "ARRAY",
                "description": "A list of all action items, tasks, or follow-ups mentioned.",
                "items": {"type": "STRING"}
            }
        },
        "required": ["summary", "action_items"]
    }

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key={API_KEY}"
    
    payload = {
        "contents": [{"parts": [{"text": user_prompt}]}],
        "systemInstruction": {"parts": [{"text": system_prompt}]},
        "generationConfig": { # Corrected key from 'config' to 'generationConfig'
            "responseMimeType": "application/json",
            "responseSchema": json_schema
        }
    }
    
    headers = {'Content-Type': 'application/json'}

    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        # The JSON response is returned as a string within the 'text' field
        json_string = result.get('candidates', [{}])[0].get('content', {}).get('parts', [{}])[0].get('text', '').strip()
        
        if json_string:
            try:
                # IMPORTANT: Clean any surrounding backticks/markdown if the API occasionally adds them
                if json_string.startswith("```json"):
                    json_string = json_string.strip("```json\n").strip("```")

                data = json.loads(json_string)
                return data, None, 200
            except json.JSONDecodeError as e:
                error_message = f"Failed to decode JSON from Gemini: {e}. Raw response start: {json_string[:200]}..."
                print(error_message)
                return None, error_message, 500
        
        error_message = "Gemini API returned empty or non-parsable response."
        print(error_message)
        # print(f"Raw API response: {response.text}") # For debugging empty responses
        return None, error_message, 500
        
    except requests.exceptions.HTTPError as e:
        # This captures the 400 Client Error specifically
        error_message = f"Gemini API Request Error (Summary): {e}. Check API key and input format."
        print(f"Error details: {e}")
        print(f"Raw Error Response: {response.text}") # Added for better debugging
        return None, error_message, response.status_code
    except requests.exceptions.RequestException as e:
        error_message = f"Gemini API Network Error: {e}"
        print(error_message)
        return None, error_message, 500


# --- Vosk Transcription Functions (Unchanged) ---

def convert_audio_to_wav(audio_bytes, sample_rate=16000):
    """Converts audio file bytes to 16kHz mono WAV format using FFmpeg."""
    temp_input_file = 'temp_input' + str(time.time()).replace('.', '')
    temp_output_wav = 'temp_converted.wav'
    
    print("Running FFmpeg conversion...")

    try:
        # Write the uploaded file bytes to a temporary file
        with open(temp_input_file, 'wb') as f:
            f.write(audio_bytes)
        
        # FFmpeg command to convert the file to 16kHz mono WAV (required by Vosk)
        command = [
            'ffmpeg',
            '-i', temp_input_file,
            '-ar', str(sample_rate),
            '-ac', '1',  # Mono
            '-f', 'wav',
            temp_output_wav,
            '-y' # Overwrite output file without asking
        ]
        
        # Execute the FFmpeg command
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        print("FFmpeg conversion complete.")
        return temp_output_wav, None
    except subprocess.CalledProcessError as e:
        return None, f"FFmpeg Error: Conversion failed. Is FFmpeg installed and in your PATH? Error: {e}"
    except Exception as e:
        return None, f"File I/O Error during conversion: {e}"
    finally:
        # Clean up the original input file
        if os.path.exists(temp_input_file):
            os.remove(temp_input_file)


def get_real_transcript_from_audio(audio_bytes, sample_rate=16000):
    """Converts audio bytes to WAV, transcribes using Vosk, and cleans up files."""
    if VOSK_MODEL is None:
        return None, "Vosk model failed to load. Cannot transcribe."
        
    temp_output_wav, error = convert_audio_to_wav(audio_bytes, sample_rate)
    if error:
        return None, error

    try:
        # Use 'with' to ensure the file handle is closed, preventing PermissionError (WinError 32)
        with wave.open(temp_output_wav, 'rb') as wf:
            if wf.getnchannels() != 1 or wf.getsampwidth() != 2 or wf.getframerate() != sample_rate:
                # This should not happen if FFmpeg conversion was successful
                return None, "Vosk input file has incorrect format."
                
            rec = KaldiRecognizer(VOSK_MODEL, sample_rate)
            rec.SetWords(False) # Get full sentence transcription

            while True:
                data = wf.readframes(4000)
                if len(data) == 0:
                    break
                rec.AcceptWaveform(data)

            result = json.loads(rec.FinalResult())
            transcript = result.get('text', '').strip()
            
            if not transcript:
                 return None, "Vosk could not transcribe the audio. The file might be silent or corrupt."
            
            return transcript, None

    except Exception as e:
        return None, f"Vosk or Wave file processing error: {e}"
    finally:
        # Clean up the converted WAV file
        if os.path.exists(temp_output_wav):
            try:
                os.remove(temp_output_wav)
            except PermissionError as e:
                 # Should be avoided by 'with open' but leaving error handling just in case
                print(f"Warning: Could not remove temporary file {temp_output_wav}: {e}")
            except Exception as e:
                print(f"Error during file cleanup: {e}")

# --- Email Function (Unchanged) ---

def send_summary_email(recipient_email, summary_data):
    """Connects to SMTP server and sends a real email."""
    sender_email, sender_password, smtp_server, smtp_port = get_email_credentials()
    
    if not all([sender_email, sender_password]):
        return False, "Email credentials (SENDER_EMAIL or SENDER_PASSWORD) are missing in .env file."
        
    try:
        # Format the email content
        summary_text = summary_data.get('summary', 'No Summary provided.')
        actions_list = "\n".join([f"- {item}" for item in summary_data.get('action_items', [])])
        
        email_body = f"""
        <html>
        <body>
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; border: 1px solid #ddd; padding: 20px;">
                <h2 style="color: #4f46e5;">ActionPoint AI Meeting Summary</h2>
                
                <h3 style="border-bottom: 2px solid #ccc; padding-bottom: 5px;">Summary</h3>
                <p style="white-space: pre-wrap;">{summary_text}</p>
                
                <h3 style="border-bottom: 2px solid #ccc; padding-bottom: 5px; margin-top: 20px;">Action Items ({len(summary_data.get('action_items', []))})</h3>
                <ul style="list-style-type: none; padding-left: 0;">
                    {"".join([f'<li style="margin-bottom: 10px; padding: 10px; border-left: 3px solid #f97316; background-color: #f7f7f7;">{item}</li>' for item in summary_data.get('action_items', [])])}
                </ul>
                
                <p style="margin-top: 30px; font-size: 0.9em; color: #888;">Report generated by ActionPoint AI.</p>
            </div>
        </body>
        </html>
        """

        msg = MIMEMultipart('alternative')
        msg['Subject'] = "Meeting Summary & Action Items from ActionPoint AI"
        msg['From'] = sender_email
        msg['To'] = recipient_email
        
        part1 = MIMEText(summary_text, 'plain')
        part2 = MIMEText(email_body, 'html')
        
        msg.attach(part1)
        msg.attach(part2)

        # Connect to the SMTP server (using TLS encryption)
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.ehlo()
            server.starttls()  # Start TLS encryption
            server.ehlo()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipient_email, msg.as_string())
        
        return True, "Email successfully sent."

    except smtplib.SMTPAuthenticationError:
        return False, "SMTP Authentication Failed. Check your SENDER_PASSWORD (App Password) and SENDER_EMAIL in the .env file."
    except smtplib.SMTPException as e:
        return False, f"SMTP Error: Could not send email. Check SMTP_SERVER/SMTP_PORT or network: {e}"
    except Exception as e:
        return False, f"Unexpected Email Error: {e}"


# --- Flask Routes ---

@app.route('/process_audio', methods=['POST'])
def process_audio():
    """Endpoint to handle audio file upload, transcription, and summarization."""
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided."}), 400

    audio_file = request.files['audio']
    audio_bytes = audio_file.read()

    # 1. Transcription (Vosk)
    transcript, error = get_real_transcript_from_audio(audio_bytes)
    if error:
        print(f"Transcription Failed: {error}")
        return jsonify({"error": error, "transcript": ""}), 500

    if len(transcript) < 50:
         return jsonify({"error": "Transcript too short. Please upload a longer audio file.", "transcript": transcript}), 400

    # 2. Summarization (Gemini API)
    summary_data, error, status_code = get_summary_and_actions(transcript)

    if error:
        return jsonify({"error": error, "transcript": transcript}), status_code

    return jsonify({
        "summary": summary_data.get('summary', 'No summary generated.'),
        "action_items": summary_data.get('action_items', []),
        "transcript": transcript
    }), 200

@app.route('/process_transcript', methods=['POST'])
def process_transcript():
    """Endpoint to handle raw text transcript summarization."""
    data = request.get_json()
    transcript = data.get('transcript', '').strip()

    if not transcript or len(transcript) < 50:
        return jsonify({"error": "Please provide a transcript of at least 50 characters."}), 400

    # 2. Summarization (Gemini API)
    summary_data, error, status_code = get_summary_and_actions(transcript)

    if error:
        return jsonify({"error": error, "transcript": transcript}), status_code

    return jsonify({
        "summary": summary_data.get('summary', 'No summary generated.'),
        "action_items": summary_data.get('action_items', []),
        "transcript": transcript
    }), 200


@app.route('/send_summary', methods=['POST'])
def send_summary():
    """Endpoint to send the generated summary and action items via real email."""
    data = request.get_json()
    recipient_email = data.get('recipient_email')
    summary_data = data.get('summary_data')

    if not recipient_email or not summary_data:
        return jsonify({"error": "Missing recipient email or summary data."}), 400

    # Execute the real email sending logic
    success, message = send_summary_email(recipient_email, summary_data)

    if success:
        print(f"Email successfully sent to {recipient_email}")
        return jsonify({"message": f"Summary successfully sent to {recipient_email}"}), 200
    else:
        print(f"Email Failed to Send to {recipient_email}: {message}")
        return jsonify({"error": f"Failed to send email: {message}"}), 500

# --- Start Server ---
if __name__ == '__main__':
    app.run(debug=True)
