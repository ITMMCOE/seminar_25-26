// frontend/src/App.js

import React, { useState } from 'react';
import './App.css'; // For Tailwind CSS directives

function App() {
  // State for the input transcript text (will also display generated transcript)
  const [transcriptText, setTranscriptText] = useState('');
  // State for the selected audio file
  const [audioFile, setAudioFile] = useState(null);
  // State to store the extracted action items
  const [actionItems, setActionItems] = useState([]);
  // State to store the generated summary
  const [summary, setSummary] = useState('');
  // State to manage loading indicator during API calls
  const [loading, setLoading] = useState(false);
  // State to indicate if audio is being transcribed (simulated)
  const [transcribing, setTranscribing] = useState(false);
  // State to store any error messages
  const [error, setError] = useState('');
  // State to control visibility of instructions
  const [showInstructions, setShowInstructions] = useState(true);
  // State for feedback modal visibility
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);
  // State to hold the action item currently being reviewed for feedback
  const [feedbackItem, setFeedbackItem] = useState(null);
  // State for the actual feedback text from the user
  const [feedbackText, setFeedbackText] = useState('');

  // Function to handle transcript or audio submission
  const handleSubmit = async () => {
    setError(''); // Clear previous errors
    setActionItems([]); // Clear previous results
    setSummary(''); // Clear previous summary
    setTranscriptText(''); // Clear transcript text area before new processing

    let endpoint = '';
    let body = {};

    if (audioFile) {
      endpoint = 'process_audio';
      const formData = new FormData();
      formData.append('audio', audioFile);
      body = formData;
      setTranscribing(true); // Indicate transcription is happening
    } else if (transcriptText.trim()) {
      endpoint = 'process_transcript';
      body = JSON.stringify({ transcript_text: transcriptText });
    } else {
      setError('Please enter a transcript or upload an audio/text file.');
      return;
    }

    setLoading(true); // Start general loading
    try {
      const fetchOptions = {
        method: 'POST',
        headers: audioFile ? {} : { 'Content-Type': 'application/json' }, // FormData handles its own Content-Type
        body: body,
      };

      const response = await fetch(`http://localhost:5000/${endpoint}`, fetchOptions);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || `Failed to process ${audioFile ? 'audio' : 'transcript'}.`);
      }

      const data = await response.json();
      setActionItems(data.action_items || []);
      setSummary(data.summary || 'No summary available.');
      // Update transcriptText with the transcript received from the backend (simulated or direct)
      setTranscriptText(data.transcript_text || ''); 

    } catch (err) {
      setError(`Error: ${err.message}`);
    } finally {
      setLoading(false); // End general loading
      setTranscribing(false); // End transcription loading
    }
  };

  // Function to handle text file upload
  const handleTextFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setError('');
      setAudioFile(null); // Clear audio file
      // setAudioDescription(''); // No longer needed
      const reader = new FileReader();
      reader.onload = (e) => {
        setTranscriptText(e.target.result);
      };
      reader.onerror = () => {
        setError('Failed to read text file.');
      };
      reader.readAsText(file);
    }
  };

  // Function to handle audio file upload
  const handleAudioFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      setError('');
      setTranscriptText(''); // Clear text transcript
      setAudioFile(file);
    }
  };

  // Function to open the feedback modal
  const openFeedbackModal = (item) => {
    setFeedbackItem(item);
    setFeedbackText('');
    setShowFeedbackModal(true);
  };

  // Function to close the feedback modal
  const closeFeedbackModal = () => {
    setShowFeedbackModal(false);
    setFeedbackItem(null);
  };

  // Function to handle feedback submission (simulated)
  const handleFeedbackSubmit = () => {
    if (feedbackItem && feedbackText.trim()) {
      console.log('Feedback submitted for item:', feedbackItem);
      console.log('User feedback:', feedbackText);
      // In a real application, you would send this feedback to your backend
      alert('Thank you for your feedback! (Check console for details)');
      closeFeedbackModal();
    } else {
      alert('Please enter your feedback.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-800 flex flex-col items-center p-4 sm:p-6 lg:p-8">
      {/* Header Section */}
      <header className="w-full max-w-4xl bg-gradient-to-r from-blue-600 to-purple-700 text-white p-6 rounded-xl shadow-lg mb-8">
        <h1 className="text-3xl sm:text-4xl font-bold text-center mb-2">
          ActionPoint AI
        </h1>
        <p className="text-xl text-center opacity-90">
          Intelligent Meeting Action Item Extractor
        </p>
      </header>

      {/* Instructions Section */}
      <section className="w-full max-w-4xl bg-white p-6 rounded-xl shadow-md mb-8">
        <button
          onClick={() => setShowInstructions(!showInstructions)}
          className="w-full text-left text-lg font-semibold text-blue-700 hover:text-blue-900 focus:outline-none flex justify-between items-center"
        >
          How to Use
          <svg
            className={`w-5 h-5 transition-transform duration-300 ${
              showInstructions ? 'rotate-180' : ''
            }`}
            fill="currentColor"
            viewBox="0 0 20 20"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
              clipRule="evenodd"
            ></path>
          </svg>
        </button>
        {showInstructions && (
          <div className="mt-4 text-gray-700 space-y-3">
            <p>
              1. **Paste Transcript:** Copy and paste your meeting transcript
              into the text area below.
            </p>
            <p>
              2. **Upload File (Text):** Click "Choose File" to upload a
              `.txt` file containing your transcript.
            </p>
            <p>
              3. **Upload File (Audio):** Click "Choose Audio File" to upload an
              audio file (e.g., `.mp3`, `.wav`).
            </p>
            <p>
              4. **Process:** Click "Process Transcript" to let the AI extract
              action items, assignees, and deadlines.
            </p>
            <p>
              5. **Review & Feedback:** Review the extracted items. If something
              is incorrect or missing, use the "Provide Feedback" button to
              help improve the system!
            </p>
          </div>
        )}
      </section>

      {/* Input Section */}
      <section className="w-full max-w-4xl bg-white p-6 rounded-xl shadow-md mb-8">
        <h2 className="text-2xl font-semibold mb-4 text-center">
          Enter Your Meeting Transcript or Upload Audio
        </h2>
        <textarea
          className="w-full p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 resize-y min-h-[150px] text-gray-900"
          placeholder="Paste your meeting transcript here..."
          value={transcriptText}
          onChange={(e) => {
            setTranscriptText(e.target.value);
            setAudioFile(null); // Clear audio file if typing
          }}
          rows="8"
          // Disable the textarea if an audio file is selected, to prevent conflicting inputs
          disabled={audioFile !== null} 
        ></textarea>

        <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4 mt-6">
          <label className="block w-full sm:w-auto text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer rounded-full border border-blue-200">
            Choose Text File
            <input
              type="file"
              accept=".txt,.docx" // Added .docx for common use, though backend only processes text
              onChange={handleTextFileChange}
              className="hidden"
              // Disable if an audio file is selected
              disabled={audioFile !== null} 
            />
          </label>
          <label className="block w-full sm:w-auto text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-purple-50 file:text-purple-700 hover:file:bg-purple-100 cursor-pointer rounded-full border border-purple-200">
            Choose Audio File
            <input
              type="file"
              accept="audio/*" // Accept any audio format
              onChange={handleAudioFileChange}
              className="hidden"
              // Disable if text is typed or a text file is selected
              disabled={transcriptText.trim() !== ''} 
            />
          </label>
          <button
            onClick={handleSubmit}
            className="w-full sm:w-auto px-8 py-3 bg-blue-600 text-white font-bold rounded-full shadow-lg hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 transition-all duration-200 flex items-center justify-center disabled:opacity-50 disabled:cursor-not-allowed"
            // Disable button if loading, or if no text and no audio file are provided
            disabled={loading || (!transcriptText.trim() && !audioFile)}
          >
            {loading ? (
              <>
                <svg
                  className="animate-spin h-5 w-5 mr-3 text-white"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  ></circle>
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                  ></path>
                </svg>
                {transcribing ? 'Transcribing Audio...' : 'Processing Transcript...'}
              </>
            ) : (
              'Process Transcript'
            )}
          </button>
        </div>
        {/* Display selected audio filename or a generic message for text input */}
        {(audioFile || transcriptText) && (
          <p className="mt-4 text-gray-600 text-center text-sm">
            {audioFile ? `Selected Audio: ${audioFile.name}` : `Text entered or file uploaded.`}
          </p>
        )}
        {error && (
          <p className="mt-4 text-red-600 text-center font-medium">{error}</p>
        )}
      </section>

      {/* Results Section - Only show if summary or action items are available */}
      {(summary || actionItems.length > 0) && (
        <section className="w-full max-w-4xl bg-white p-6 rounded-xl shadow-md mb-8">
          <h2 className="text-2xl font-semibold mb-6 text-center">
            Analysis Results
          </h2>

          {/* Summary Section */}
          {summary && (
            <div className="mb-8 p-5 bg-green-50 rounded-lg border border-green-200 shadow-sm">
              <h3 className="text-xl font-semibold text-green-800 mb-3">Meeting Summary</h3>
              <p className="text-gray-700 leading-relaxed">{summary}</p>
            </div>
          )}

          {/* Action Items Section */}
          {actionItems.length > 0 && (
            <>
              <h3 className="text-xl font-semibold text-blue-800 mb-4">Extracted Action Items</h3>
              <div className="space-y-6">
                {actionItems.map((item) => (
                  <div
                    key={item.id} // Unique key for React list rendering
                    className="bg-blue-50 p-5 rounded-lg border border-blue-200 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4"
                  >
                    <div className="flex-grow">
                      <p className="text-lg font-medium text-blue-800 mb-1">
                        <span className="font-bold">Action:</span> {item.action}
                      </p>
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Assignee:</span>{' '}
                        {item.assignee}
                      </p>
                      <p className="text-sm text-gray-700">
                        <span className="font-semibold">Deadline:</span>{' '}
                        {item.deadline}
                      </p>
                      <p className="text-xs text-gray-500 mt-2 italic">
                        Original: "{item.original_sentence}"
                      </p>
                    </div>
                    <button
                      onClick={() => openFeedbackModal(item)}
                      className="px-4 py-2 bg-purple-600 text-white text-sm font-semibold rounded-full hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-opacity-75 transition-all duration-200"
                    >
                      Provide Feedback
                    </button>
                  </div>
                ))}
              </div>
            </>
          )}
        </section>
      )}

      {/* Feedback Modal */}
      {showFeedbackModal && feedbackItem && (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center p-4 z-50">
          <div className="bg-white p-8 rounded-xl shadow-2xl max-w-md w-full">
            <h2 className="text-2xl font-bold mb-4 text-gray-800">
              Provide Feedback
            </h2>
            <p className="mb-4 text-gray-700">
              Help us improve! What was incorrect or could be better about this
              extraction?
            </p>
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200 mb-6">
              <p className="text-blue-800 font-medium">
                **Action:** {feedbackItem.action}
              </p>
              <p className="text-sm text-gray-700">
                **Assignee:** {feedbackItem.assignee}
              </p>
              <p className="text-sm text-gray-700">
                **Deadline:** {feedbackItem.deadline}
              </p>
            </div>
            <textarea
              className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-200 resize-y min-h-[100px] text-gray-900"
              placeholder="Your feedback here..."
              value={feedbackText}
              onChange={(e) => setFeedbackText(e.target.value)}
              rows="4"
            ></textarea>
            <div className="flex justify-end space-x-3 mt-6">
              <button
                onClick={closeFeedbackModal}
                className="px-6 py-2 bg-gray-200 text-gray-800 font-semibold rounded-full hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-gray-400 transition-all duration-200"
              >
                Cancel
              </button>
              <button
                onClick={handleFeedbackSubmit}
                className="px-6 py-2 bg-blue-600 text-white font-bold rounded-full shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-75 transition-all duration-200"
              >
                Submit Feedback
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Sample Transcript for Easy Testing */}
      <section className="w-full max-w-4xl bg-white p-6 rounded-xl shadow-md mt-8">
        <h2 className="text-2xl font-semibold mb-4 text-center">
          Sample Transcript (for quick testing)
        </h2>
        <pre className="bg-gray-50 p-4 rounded-lg border border-gray-200 text-sm whitespace-pre-wrap break-words text-gray-800">
          John: Good morning everyone. Let's discuss the Q3 report. I will
          finalize the data analysis by tomorrow. Sarah, can you please prepare
          the presentation slides by next Tuesday? We need to ensure all figures
          are updated. Mark: I will review the marketing section by end of day.
          Also, we should schedule the next team meeting for July 30, 2025.
          Everyone needs to send their individual progress reports by Friday.
          Lisa: I'll confirm the client feedback by end of week.
        </pre>
      </section>
    </div>
  );
}

export default App;
