import React, { useState, useCallback, useRef, useEffect } from 'react';
import { Share2, FileText, Mic, Send, Loader2, Link, Copy, X } from 'lucide-react';

const API_BASE_URL = 'http://127.0.0.1:5000';

// Global styles are assumed via Tailwind CSS configuration

/**
 * Custom hook to handle API calls with loading and error states.
 */
const useApiCall = (initialData = {}) => {
  const [data, setData] = useState(initialData);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const call = useCallback(async (endpoint, options) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
      
      // Check for non-200 status codes first
      if (!response.ok) {
        let errorData;
        try {
          // Attempt to parse JSON error message from the backend
          errorData = await response.json();
        } catch (e) {
          // If response is not JSON, use the status text
          errorData = { error: response.statusText };
        }
        
        // Use the error message from the backend, or a default
        const errorMessage = errorData.error || `Server responded with status ${response.status}`;
        throw new Error(errorMessage);
      }

      const result = await response.json();
      setData(result);
      return result; // Return result for further processing (like setting status message)
    } catch (err) {
      console.error("API Call Error:", err.message);
      // Ensure the error state is a simple string for display
      setError(err.message.startsWith('Failed to fetch') 
        ? 'Network error. Is the Flask server running?' 
        : err.message);
      setData(initialData); // Clear data on error
      return null;
    } finally {
      setLoading(false);
    }
  }, [initialData]);

  const clear = () => {
    setData(initialData);
    setError(null);
  };

  return { data, loading, error, call, clear };
};


/**
 * Main App Component
 */
const App = () => {
  // --- State Management ---
  const [activeTab, setActiveTab] = useState('audio'); // 'audio' or 'text'
  const [selectedFile, setSelectedFile] = useState(null);
  const [rawTranscript, setRawTranscript] = useState(''); // State for Text-to-Summary input
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [statusMessage, setStatusMessage] = useState({ type: null, text: null }); // { type: 'success'|'error', text: '...' }

  const initialSummaryData = { summary: '', action_items: [], transcript: '' };
  const { 
    data: summaryData, 
    loading: summaryLoading, 
    error: summaryError, 
    call: generateSummary, 
    clear: clearSummary 
  } = useApiCall(initialSummaryData);
  
  const fileInputRef = useRef(null);
  
  // --- Utility Functions ---

  const showStatus = useCallback((type, text) => {
    setStatusMessage({ type, text });
    setTimeout(() => setStatusMessage({ type: null, text: null }), 6000);
  }, []);

  const handleClear = () => {
    clearSummary();
    setSelectedFile(null);
    setRawTranscript('');
    setRecipientEmail('');
    if (fileInputRef.current) {
        fileInputRef.current.value = null;
    }
    showStatus('success', 'Cleared all data.');
  };

  const copyToClipboard = async (text) => {
    try {
      // Use execCommand('copy') for better compatibility inside iframes
      const tempTextArea = document.createElement('textarea');
      tempTextArea.value = text;
      document.body.appendChild(tempTextArea);
      tempTextArea.select();
      document.execCommand('copy');
      document.body.removeChild(tempTextArea);
      showStatus('success', 'Full transcript copied to clipboard!');
    } catch (err) {
      showStatus('error', 'Failed to copy text.');
    }
  };

  // --- Handlers for Audio/File Input ---

  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Basic validation for common audio types (add more as needed)
      if (!file.type.startsWith('audio/') && !file.name.toLowerCase().match(/\.(mp3|wav|ogg|m4a|flac)$/)) {
        showStatus('error', 'Invalid file type. Please upload an audio file.');
        setSelectedFile(null);
        if (fileInputRef.current) fileInputRef.current.value = null; // Clear file input
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleAudioSubmit = async (e) => {
    e.preventDefault();
    if (!selectedFile) {
      showStatus('error', 'Please select an audio file first.');
      return;
    }

    const formData = new FormData();
    formData.append('audio', selectedFile);

    showStatus('info', `Processing "${selectedFile.name}". This may take a moment...`);
    const result = await generateSummary('/process_audio', {
      method: 'POST',
      body: formData,
    });
    
    if (result) {
      showStatus('success', 'Audio successfully transcribed and summarized!');
    } else if (summaryError) {
      // The useApiCall hook already sets summaryError
      showStatus('error', summaryError);
    }
  };

  // --- Handlers for Text Input (CRITICAL SECTION FOR YOUR ISSUE) ---

  const handleTextToSummarySubmit = async (e) => {
    e.preventDefault();
    
    // Check the rawTranscript state variable content
    const cleanedTranscript = rawTranscript.trim();

    if (!cleanedTranscript || cleanedTranscript.length < 50) {
      showStatus('error', 'Please provide a transcript of at least 50 characters.');
      return;
    }

    showStatus('info', 'Generating summary from text...');
    
    const result = await generateSummary('/process_transcript', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ transcript: cleanedTranscript }),
    });

    if (result) {
      showStatus('success', 'Summary successfully generated from text!');
    } else if (summaryError) {
      showStatus('error', summaryError);
    }
  };

  // --- Email Sending Logic ---

  const handleEmailSubmit = async (e) => {
    e.preventDefault();
    if (!recipientEmail || !summaryData.summary) {
      showStatus('error', 'Please ensure you have a valid email and a generated summary.');
      return;
    }

    // Simple email validation regex (for basic format check)
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(recipientEmail)) {
        showStatus('error', 'Please enter a valid email address.');
        return;
    }

    setIsModalOpen(false); // Close modal
    showStatus('info', `Attempting to send email to ${recipientEmail}...`);

    try {
      const response = await fetch(`${API_BASE_URL}/send_summary`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          recipient_email: recipientEmail,
          summary_data: {
            summary: summaryData.summary,
            action_items: summaryData.action_items,
          },
        }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        // Log the full error to the console for debugging
        console.error("Email Send Error Response:", data);
        throw new Error(data.error || 'Failed to send email due to a server error.');
      }
      
      showStatus('success', data.message || `Summary successfully sent to ${recipientEmail}!`);
    } catch (err) {
      showStatus('error', err.message);
    }
  };
  
  // --- Component Rendering ---

  const ActionItemDisplay = ({ items }) => (
    <div className="mt-4 p-4 bg-white rounded-xl shadow-lg border border-indigo-100">
      <h3 className="text-lg font-bold text-orange-600 flex items-center mb-3">
        <Link className="w-5 h-5 mr-2 text-orange-500" />
        Action Items ({items.length})
      </h3>
      {items.length > 0 ? (
        <ul className="space-y-3">
          {items.map((item, index) => (
            <li key={index} className="flex items-start text-gray-700">
              <span className="text-indigo-500 mr-2 text-xl leading-none">&bull;</span>
              {item}
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-500 italic">No explicit action items were identified in the meeting.</p>
      )}
    </div>
  );

  const StatusMessage = ({ type, text }) => {
    if (!text) return null;
    const colorClass = type === 'error' ? 'bg-red-500' : type === 'success' ? 'bg-green-500' : 'bg-blue-500';
    return (
      <div className={`fixed top-4 right-4 z-50 p-4 rounded-xl text-white shadow-xl ${colorClass} transition-opacity duration-300`}>
        {text}
      </div>
    );
  };
  
  // Determine if the results area should be shown
  const showResults = summaryData.summary || summaryData.transcript || summaryLoading || summaryError;

  return (
    <div className="min-h-screen bg-gray-50 font-sans p-4 sm:p-8">
      
      <StatusMessage type={statusMessage.type} text={statusMessage.text} />

      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-5xl font-extrabold text-indigo-700 tracking-tight">ActionPoint AI</h1>
          <p className="mt-2 text-xl text-gray-500">Transcribe, Summarize, and Share Meeting Notes Instantly.</p>
        </header>
        
        {/* --- Tab Navigation --- */}
        <div className="flex justify-center mb-6">
          <button
            onClick={() => setActiveTab('audio')}
            className={`px-6 py-3 rounded-l-xl font-semibold transition-all duration-200 ${
              activeTab === 'audio' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white text-gray-600 hover:bg-indigo-50/50'
            }`}
          >
            <Mic className="inline w-5 h-5 mr-2" />
            Audio File
          </button>
          <button
            onClick={() => setActiveTab('text')}
            className={`px-6 py-3 rounded-r-xl font-semibold transition-all duration-200 ${
              activeTab === 'text' ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white text-gray-600 hover:bg-indigo-50/50'
            }`}
          >
            <FileText className="inline w-5 h-5 mr-2" />
            Text-to-Summary
          </button>
        </div>

        {/* --- Input Area --- */}
        <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-2xl mb-8 border border-indigo-200/50">
          {activeTab === 'audio' ? (
            <form onSubmit={handleAudioSubmit}>
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center"><Mic className="w-6 h-6 mr-2 text-indigo-500"/> Upload Audio</h2>
              <input
                ref={fileInputRef}
                type="file"
                accept="audio/*,.mp3,.wav,.ogg,.m4a,.flac"
                onChange={handleFileChange}
                className="block w-full text-sm text-gray-500
                  file:mr-4 file:py-2 file:px-4
                  file:rounded-full file:border-0
                  file:text-sm file:font-semibold
                  file:bg-indigo-50 file:text-indigo-700
                  hover:file:bg-indigo-100/70 cursor-pointer"
              />
              {selectedFile && (
                <p className="mt-3 text-sm text-gray-600">Selected: <span className="font-medium text-indigo-600">{selectedFile.name}</span></p>
              )}
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  type="button"
                  onClick={handleClear}
                  className="px-6 py-3 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-100 transition duration-150"
                  disabled={summaryLoading}
                >
                  Clear
                </button>
                <button
                  type="submit"
                  className="flex items-center justify-center px-6 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition duration-150 shadow-md disabled:bg-indigo-300"
                  disabled={!selectedFile || summaryLoading}
                >
                  {summaryLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Send className="w-5 h-5 mr-2" />}
                  Transcribe & Summarize
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleTextToSummarySubmit}>
              <h2 className="text-2xl font-bold text-gray-800 mb-4 flex items-center"><FileText className="w-6 h-6 mr-2 text-indigo-500"/> Paste Transcript</h2>
              <textarea
                value={rawTranscript}
                onChange={(e) => setRawTranscript(e.target.value)}
                rows="8"
                placeholder="Paste your meeting transcript here (at least 50 characters)..."
                className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition duration-150 resize-none"
              ></textarea>
              <div className="flex justify-end space-x-4 mt-6">
                <button
                  type="button"
                  onClick={handleClear}
                  className="px-6 py-3 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-100 transition duration-150"
                  disabled={summaryLoading}
                >
                  Clear
                </button>
                <button
                  type="submit"
                  className="flex items-center justify-center px-6 py-3 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition duration-150 shadow-md disabled:bg-indigo-300"
                  disabled={summaryLoading || rawTranscript.trim().length < 50}
                >
                  {summaryLoading ? <Loader2 className="w-5 h-5 mr-2 animate-spin" /> : <Send className="w-5 h-5 mr-2" />}
                  Generate Summary
                </button>
              </div>
            </form>
          )}
        </div>

        {/* --- Results Display Area --- */}
        {showResults && (
          <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-2xl border border-indigo-200/50">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Results</h2>

            {summaryLoading && (
              <div className="flex items-center justify-center p-8 text-indigo-600">
                <Loader2 className="w-8 h-8 mr-3 animate-spin" />
                <span className="text-xl font-semibold">Analyzing and Summarizing...</span>
              </div>
            )}
            
            {summaryError && (
              <div className="p-4 bg-red-100 border border-red-400 text-red-700 rounded-xl">
                <p className="font-bold mb-1">Error processing data:</p>
                <p>{summaryError}</p>
                {summaryData.transcript && (
                  <p className='mt-2 text-sm'>
                    **Transcript generated but failed to summarize.** (Length: {summaryData.transcript.length} chars)
                  </p>
                )}
              </div>
            )}

            {!summaryLoading && !summaryError && summaryData.transcript && (
              <div className='space-y-6'>
                {/* Transcript */}
                <div className="p-4 bg-gray-100 rounded-xl border border-gray-300">
                  <h3 className="text-lg font-bold text-gray-700 flex items-center mb-2">
                    <FileText className="w-5 h-5 mr-2 text-gray-500" />
                    Full Transcript
                  </h3>
                  <p className="text-gray-600 text-sm italic max-h-40 overflow-y-auto whitespace-pre-wrap">{summaryData.transcript}</p>
                  <button
                    onClick={() => copyToClipboard(summaryData.transcript)}
                    className="mt-3 text-sm text-indigo-600 hover:text-indigo-800 flex items-center font-medium transition duration-150"
                  >
                    <Copy className="w-4 h-4 mr-1" /> Copy Transcript
                  </button>
                </div>

                {/* Summary */}
                <div className="p-4 bg-indigo-50 rounded-xl shadow-lg border border-indigo-200">
                  <h3 className="text-xl font-bold text-indigo-700 mb-3">Meeting Summary</h3>
                  <p className="text-gray-800 whitespace-pre-wrap">{summaryData.summary}</p>
                </div>

                {/* Action Items */}
                <ActionItemDisplay items={summaryData.action_items} />
                
                {/* Share Button */}
                <div className="flex justify-end pt-4">
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center px-6 py-3 bg-orange-500 text-white font-semibold rounded-xl hover:bg-orange-600 transition duration-150 shadow-md"
                  >
                    <Share2 className="w-5 h-5 mr-2" />
                    Share Summary by Email
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
      
      {/* --- Email Modal --- */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50 p-4" onClick={() => setIsModalOpen(false)}>
          <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-3xl max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
            <div className='flex justify-between items-center mb-4'>
                <h3 className="text-2xl font-bold text-indigo-700">Email Summary</h3>
                <button onClick={() => setIsModalOpen(false)} className='text-gray-400 hover:text-gray-600'><X className='w-6 h-6'/></button>
            </div>
            <p className="text-gray-600 mb-4">Send the generated summary and action items to an email address.</p>
            
            <form onSubmit={handleEmailSubmit}>
              <label htmlFor="recipient-email" className="block text-sm font-medium text-gray-700 mb-1">Recipient Email Address</label>
              <input
                id="recipient-email"
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="email@example.com"
                required
                className="w-full p-3 border border-gray-300 rounded-xl focus:ring-indigo-500 focus:border-indigo-500 transition duration-150"
              />
              
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-5 py-2 border border-gray-300 rounded-xl text-gray-700 font-semibold hover:bg-gray-100 transition duration-150"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center px-5 py-2 bg-indigo-600 text-white font-semibold rounded-xl hover:bg-indigo-700 transition duration-150 shadow-md"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Send Summary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;


