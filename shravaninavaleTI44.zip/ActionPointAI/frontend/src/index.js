import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';

// Get the root element from public/index.html
const rootElement = document.getElementById('root');

// Create the root and render the App component
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
} else {
  console.error("Failed to find the root element in the HTML.");
}
