// seminar2.js (ES module / Firebase v9 modular)
// Make sure your HTML loads this file with:
// <script type="module" src="seminar2.js"></script>

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-app.js";
import { getFirestore, collection, addDoc } from "https://www.gstatic.com/firebasejs/9.22.1/firebase-firestore.js";

console.log("seminar2.js loaded");

// ✅ Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyCWbZ6VeD4-ocKQ6YeGvVC1c30SZY_ouEw",
  authDomain: "chatbot-enquiry.firebaseapp.com",
  projectId: "chatbot-enquiry",
  storageBucket: "chatbot-enquiry.firebasestorage.app",
  messagingSenderId: "404991536518",
  appId: "1:404991536518:web:6f5f7cfe1a76e7f9695007",
  measurementId: "G-YTNFEHM0LC"
};

// Initialize Firebase (modular)
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

// Dataset (Civil removed)
const dataset = {
  "overview": "🏫 <b>MMCOE Overview</b><br>Marathwada Mitra Mandal's College of Engineering (MMCOE), Pune is affiliated to SPPU and accredited by NAAC & NBA. The institute offers UG and PG programs across multiple engineering branches and management studies. MMCOE focuses on quality technical education, research, industry collaboration and entrepreneurship.",
  "vision_mission": "🎯 <b>Vision & Mission</b><br><b>Vision:</b> To be a centre of excellence in engineering education, research and innovation.<br><b>Mission:</b> Provide industry-oriented education, foster research & entrepreneurship, and develop socially responsible professionals.",
  "history_accreditation": "📜 <b>History & Accreditation</b><br>Established by Marathwada Mitra Mandal, MMCOE has steadily grown in academics and infrastructure. Approved by AICTE, affiliated to SPPU, and accredited by NAAC & NBA for several programs.",
  "departments": "🏷️ <b>Departments</b><br>• Computer Engineering<br>• Information Technology<br>• Electronics & Telecommunication (E&TC)<br>• Mechanical Engineering<br>• Master of Business Administration (MBA)",
  "courses": "📚 <b>Academic Programs</b><br>• B.Tech - Computer Engg, IT, E&TC, Mechanical<br>• M.Tech (selected specializations)<br>• MBA (Management)",
  "fees": "💰 <b>Fee Structure (Indicative)</b><br>For 2024-25: UG Engineering approx. ₹1,10,000 per year; MBA approx. ₹1,50,000 per year. Exact fees follow DTE/SPPU guidelines and seat type (government/CAP/NRI).",
  "admission": "🎓 <b>Admissions</b><br>UG: Through MHT-CET / JEE Main and centralized CAP rounds. PG: Through GATE / PGCET or institute-level criteria as per university rules. For admission details, refer to official prospectus.",
  "placement": "🚀 <b>Placements & Training</b><br>• Highest Package (2023-24): 15 LPA (Product-based roles)<br>• Average Package: ~4.5 LPA<br>• Major Recruiters: TCS, Infosys, Cognizant, Capgemini, Tech Mahindra, Persistent, startups and core companies.<br>• T&P Process: Registration → Pre-placement talks → Aptitude / Tech test → Technical interviews → HR rounds.",
  "internships": "💼 <b>Internships</b><br>• Coordinated by Training & Placement cell (T&P).<br>• Internships available with IT firms, core engineering companies, startups and research labs.<br>• Stipends vary (₹5,000–₹20,000/month depending on company & role).",
  "infrastructure": "🏢 <b>Campus Infrastructure</b><br>• Modern labs & research centres<br>• Smart classrooms & seminar halls<br>• Central library with digital resources and 50,000+ books<br>• Auditorium, auditorium facilities, indoor & outdoor sports complex, cafeteria, medical room",
  "library": "📚 <b>Library & Digital Resources</b><br>• Central library provides access to e-journals, IEEE, Elsevier, Springer, NPTEL, and e-books.<br>• Digital library terminals, membership, inter-library loan for research students.",
  "research_patents": "🔬 <b>Research & Patents</b><br>• Active research groups across departments.<br>• Support for patents, industry-funded projects, and consultancy.<br>• Incubation and mentorship via FMCIII and entrepreneurship cell.",
  "alumni": "🎓 <b>Alumni Network</b><br>• Active alumni association with industry leaders and startup founders.<br>• Alumni mentorship programs, guest lectures, and placement assistance.",
  "clubs": "🤝 <b>Clubs & Student Chapters</b><br>• Coding Club, Robotics Club, EESA, ACM, IEEE, CSI student chapters, Entrepreneurship Cell (E-Cell), Cultural & Drama clubs, Sports clubs.",
  "events": "🎉 <b>Events & Fests</b><br>• Technical Fest: Avenir<br>• Cultural Fest: Inspira<br>• Hackathons, workshops, industrial visits, seminars, and guest lectures throughout the year.",
  "hostel": "🏠 <b>Hostel Facilities</b><br>• Separate hostels for boys & girls, mess with veg/non-veg options, WiFi, gym, reading room, medical facilities, wardens & security. Hostel fees approx. ₹65,000/year (subject to changes).",
  "transport": "🚌 <b>Transport Facility</b><br>• College buses on major city routes (timings per academic calendar).<br>• Transport fee as per semester policy. Apply at transport office for route allocation.",
  "scholarships": "🎓 <b>Scholarships & Financial Aid</b><br>• Scholarships available for meritorious and needy students through government schemes, institute scholarships, and external funding. Check scholarship cell and website for eligibility and application process.",
  "attendance_rules": "📋 <b>Attendance & Academic Rules</b><br>• Minimum attendance: 75% per subject to be eligible for examinations (as per university/autonomous rules).<br>• Shortage of attendance cases are handled per institutional policy (medical / valid reasons with documentation).",
  "exams_assessment": "📝 <b>Examinations & Assessment</b><br>• Continuous Internal Evaluation (CIE) + Semester End Examination (SEE) pattern.<br>• Typical CIE: quizzes, assignments, lab work, mid-sem tests. SEE: end-semester written/practical exams.<br>• Passing: As per autonomous grading & credit policy (see 'grading_system').",
  "contact": "📞 <b>Contact Info</b><br>MMCOE, Karvenagar, Pune – 411052<br>Phone: +91-20-25479811<br>Email: info@mmcoe.edu.in<br>Training & Placement: tp@mmcoe.edu.in",
  "faq": "<b>Frequently Asked Questions (Short)</b><br>• Q: How to apply? A: Follow DTE CAP rounds or institute admission portal for PG.<br>• Q: Hostel availability? A: Apply online; priority based on year & seat availability.<br>• Q: Where to get syllabus? A: University / Institute website and department office.",
  "how_to_apply_documents": "📄 <b>How to Apply for Bonafide / TC / Documents</b><br>• Fill the online form on the student portal or visit the admin office.<br>• Submit required identity proof and fees. Processing time ~3–7 working days.",
  "anti_ragging": "⚖️ <b>Anti-Ragging & Student Safety</b><br>• Strict anti-ragging policy. Complaints are handled confidentially via the anti-ragging cell and grievance redressal committee.",
  "code_of_conduct": "🧾 <b>Code of Conduct</b><br>• Students must follow college discipline, dress code where applicable, respect faculty & staff, maintain academic honesty and campus cleanliness.",
  "placements_steps": "<b>Training & Placement - Typical Steps</b><br>1) Student registration on T&P portal<br>2) Resume shortlisting & pre-placement talks<br>3) Written / online tests (aptitude/technical)<br>4) Technical interviews (subject-based)<br>5) HR interviews & offer letters<br>6) Acceptance & joining formalities",
  "alumni_success": "🏅 <b>Alumni Success Stories</b><br>• Alumni working at top firms and founding startups; many contribute back through mentorship and placements.",
  "skill_programs": "🧠 <b>Skill Development Programs</b><br>• Value-added courses: AI/ML, Data Science, Cloud, Cybersecurity, IoT, Embedded Systems; certificate programs via industry partners.",
  "grievance_cell": "📣 <b>Grievance & Counselling</b><br>• The institute provides counselling services and a grievance redressal mechanism via the student affairs office.",
  "placements_statistics": "📊 <b>Placement Statistics (Recent)</b><br>• Placement Percentage: ~60-80% (varies by batch & branch)<br>• Top recruiters across IT, product, and core domains.",
  "tough_subjects": "📘 <b>Tough Subjects & Tips</b><br>• Compiler Design: Practice small compiler modules & understanding automata.<br>• DBMS: Focus on normalization, transactions & SQL practice.<br>• DSP: Strong math practice, numerical problems.<br>• OS/Networks: Understand core concepts and lab implementations.<br>• Tip: Solve previous year papers and implement mini-projects.",
  "electives": "📖 <b>Electives & Career Pathways</b><br>• Popular electives: AI/ML, Data Science, Cloud Computing, Cybersecurity, Embedded Systems, Advanced DB.<br>• Choose electives aligned with career goals (industry or research).",
  "internship_process": "🔍 <b>How to Get Internships</b><br>1) Register on T&P portal<br>2) Prepare resume & GitHub/portfolio<br>3) Attend placement drives & apply to companies directly<br>4) Use faculty & alumni networks for internships",
  "fmciii": "🚀 <b>FMCIII & Incubation</b><br>• FMCIII supports incubation, seed funding, mentorship, hackathons, and bridging research-to-product initiatives.",
  "extra_curricular": "🎭 <b>Extra Curricular Activities</b><br>• Cultural events, sports, music, drama, debate clubs, technical workshops and student-run societies keep campus life vibrant.",
  "clubs_contact": "📌 <b>Club Contacts</b><br>• Coding Club: codingclub@mmcoe.edu.in<br>• E-Cell: ecell@mmcoe.edu.in<br>• IEEE/ACM/CSI chapters through department offices.",
  
 "career_paths": `
<b>Various Career Paths After Engineering/MMCOE</b><br>
• <u>Software Developer / IT:</u> SDE, app/web dev, backend/frontend, QA, DevOps.<br>
  - Skills: C/C++, Java, Python, JS/React, Git, cloud.<br>
  - Path: Solve DSA, build projects, open-source, hackathons, internships.<br>
• <u>Data Science / AI / ML:</u> Data Analyst, ML Engineer, Data Scientist, NLP Engineer.<br>
  - Skills: Python, R, SQL, Pandas, TensorFlow, PyTorch, cloud platforms.<br>
  - Path: Take AI/ML electives, complete certifications, build ML projects, participate in Kaggle and competitions, do internships.<br>
• <u>Cybersecurity:</u> InfoSec engineer, penetration tester, security analyst.<br>
  - Skills: Linux, networks, cryptography, Python, CTF competitions, CEH/CISSP.<br>
  - Path: Security electives, CTF training, certifications, internships.<br>
• <u>Cloud Computing & DevOps:</u> Cloud engineer, AWS/GCP/Azure architect, DevOps manager.<br>
  - Skills: Docker, Kubernetes, CI/CD, cloud platforms.<br>
  - Path: Cloud certifications, DevOps projects, internships.<br>
• <u>Embedded / IoT / Robotics:</u> Embedded systems dev, IoT specialist, robotics engineer.<br>
  - Skills: C/C++/Python, microcontrollers, sensors.<br>
  - Path: Robotics clubs, hardware projects, competitions, industry internships.<br>
• <u>Mechanical / Core Engineering:</u> Design engineer, automation consultant.<br>
  - Skills: CAD/CAM, SolidWorks, 3D printing.<br>
  - Path: Prototyping, internships, alumni networking.<br>
• <u>Management & Consulting:</u> MBA, product manager, business analyst.<br>
  - Skills: Leadership, analytics, strategy.<br>
  - Path: B-school prep, internships, leadership roles.<br>
• <u>Entrepreneurship:</u> Startup founder, tech innovator.<br>
  - Skills: Product, business, pitching.<br>
  - Path: Incubators, FMCIII, hackathons.<br>
• <u>Higher Studies & Research:</u> MS/M.Tech/PhD.<br>
  - Path: GRE, GATE, research projects.<br>
• <u>PSU / Govt / Defence:</u> IES, DRDO, ISRO, etc.<br>
  - Path: GATE, UPSC prep.<br>
• <u>Teaching & EdTech:</u> Faculty, tutor, content creator.<br>
  - Path: M.Tech/PhD.<br>
• <u>Freelancing & Content Creation:</u> Online educator, YouTuber.<br>
  - Path: Build brand, create content.<br>

<b>How to Choose a Path?</b><br>
- Explore electives, internships, clubs.<br>
- Seek advice from mentors and alumni.<br>
- Follow industry and research trends.<br>
- Use feedback channels to suggest career resources.<br>
`,
"dsa_tips": `
💻 <b>DSA Tips & Roadmap</b><br>
• Start with basics: Arrays, Strings, Linked Lists, Stacks, Queues.<br>
• Progress to Trees, Graphs, Recursion, Sorting & Searching.<br>
• Practice solving problems daily on platforms like Leetcode, GeeksforGeeks, CodeChef.<br>
• Focus on building strong fundamentals in time and space complexity.<br>
• Understand problem-solving patterns such as sliding window, two pointers, backtracking.<br>
• Learn standard algorithms and their implementations: BFS, DFS, Dynamic Programming, Greedy.<br>
• Participate in competitive programming contests to improve speed and accuracy.<br>
• Use study resources: YouTube channels (Abdul Bari, Aditya Verma), books ('Cracking the Coding Interview').<br>
• Join peer coding groups for motivation and collaborative learning.<br>
• Keep a notebook/log of problems solved and lessons learned to track progress.<br>
• Work on mini-projects or integrate algorithms into apps to see real-world usage.<br>
`
,

  
  /* ---------------------------
     AUTONOMOUS RULES & ACADEMICS
     --------------------------- */
  "autonomous_overview": "🏛️ <b>Autonomous Status & Academic Structure</b><br>MMCOE follows autonomous regulations for examination, credit allocation, and syllabus updates while remaining affiliated to SPPU. Autonomy allows flexible curriculum updates, industry-aligned electives, and continuous assessment.",
  "grading_system": "📐 <b>Grading & Credit System</b><br>• Credit-based semester system (CBCS) with theory & practical credits.<br>• Letter grades mapped to grade points (example): O=10, A+=9, A=8, B+=7, B=6, C=5, D=4, F/Fail=0.<br>• SGPA and CGPA computed per standard formula: SGPA = Σ(credit×grade_point) / Σcredits. CGPA is cumulative across semesters.",
  "assessment_pattern": "🧾 <b>Assessment Pattern (Autonomous)</b><br>• Continuous Internal Evaluation (CIE): Assignments, quizzes, mid-term tests, labs (typically 40% weight).<br>• Semester End Examination (SEE): Theory/practicals (typically 60% weight).<br>• Project/Internship/Viva as per course requirement with separate grading.",
  "attendance_policy": "⏱️ <b>Attendance Policy (Autonomous)</b><br>• Minimum 75% attendance per subject required to be eligible for examinations.<br>• Shortage of attendance may be condoned in genuine cases per college rules (medical certificate, university norms).",
  "exam_registration_rules": "📝 <b>Exam Registration & Eligibility</b><br>• Students must register for semester exams via the portal within the stipulated dates.<br>• Clearance of dues and minimum attendance are mandatory for registration.",
  "backlog_makeup_rules": "♻️ <b>Backlog & Makeup Exams</b><br>• Failed subjects are classified as backlog; students must register for re-appearance exams.<br>• Supplementary/makeup exams scheduled per academic calendar; internal marks are retained while SEE marks are replaced upon re-exam.",
  "revaluation_policy": "🔍 <b>Revaluation & Grievance</b><br>• Students can apply for revaluation or photocopy of answer papers within specified time and fees as per autonomous rules. Grievances are addressed via the controller of exams.",
  "academic_integrity": "🔒 <b>Academic Integrity & Plagiarism</b><br>• Strict policy against plagiarism and academic dishonesty. Projects/theses must include originality reports; penalties for violation may include grade reduction or disciplinary action.",
  "credit_transfer": "🔄 <b>Credit Transfer & Lateral Entry</b><br>• Credit transfer policy for lateral entry or exchange programs is as per institutional guidelines and requires approval from the academic committee.",
  "grading_conversion": "📊 <b>Grade to Percentage Conversion (Example)</b><br>• CGPA to % formula (if required): % = (CGPA - 0.5) × 10 (Follow university/autonomous declared formula).",
  "subject_registration_rules": "🔁 <b>Subject Registration & Electives</b><br>• Students must register for core and elective courses in the beginning of the semester. Elective choices are subject to seat availability and prerequisites.",
  "attendance_consequences": "⚠️ <b>Consequences of Low Attendance</b><br>• Students with <75% may be denied SEE eligibility. Repeated non-compliance may lead to disciplinary action and mandatory remediation classes.",
  "promotion_policy": "➡️ <b>Promotion & Eligibility for Next Semester</b><br>• Promotion criteria include passing minimum credits as per academic regulations. Students may progress with backlogs but must clear them within prescribed time limits.",
  "project_guidelines": "📚 <b>Project & Minor/Major Internship Guidelines</b><br>• Projects require a guide, mid-term reviews, report submission, demo, and viva. Industry internships credited as per duration (typically min 4–6 weeks for credits).",

  /* ---------------------------
     DEPARTMENT-WISE SUBJECTS (Representative)
     --------------------------- */
  "comp_sem1": "<b>Computer Engineering - Semester 1</b><br>• Engineering Mathematics I<br>• Engineering Physics/Chemistry<br>• Basic Electrical Engineering<br>• Engineering Mechanics/Engineering Graphics<br>• Programming Fundamentals (C/Python) & Lab<br>• Environmental Studies",
  "comp_sem2": "<b>Computer Engineering - Semester 2</b><br>• Engineering Mathematics II<br>• Basic Electronics & Digital Logic<br>• Data Structures & Algorithms I & Lab<br>• Discrete Mathematics<br>• Workshop/Practical Skills",
  "comp_sem3": "<b>Computer Engineering - Semester 3</b><br>• Computer Organization & Architecture<br>• Data Structures & Algorithms II & Lab<br>• Object Oriented Programming & Lab<br>• Operating Systems - Basics<br>• Professional Communication",
  "comp_sem4": "<b>Computer Engineering - Semester 4</b><br>• Database Management Systems & Lab<br>• Computer Networks I & Lab<br>• Theory of Computation / Automata<br>• Software Engineering Principles<br>• Microprocessors & Lab",
  "comp_sem5": "<b>Computer Engineering - Semester 5</b><br>• Theory of Operating Systems<br>• Design & Analysis of Algorithms<br>• Web Technologies & Lab<br>• Elective I (AI/ML / Cloud / Cybersecurity)<br>• Mini Project / Seminar",
  "comp_sem6": "<b>Computer Engineering - Semester 6</b><br>• Compiler Design / Advanced DB (elective)<br>• Computer Networks II / Distributed Systems<br>• Elective II (Data Science / NLP / IoT)<br>• Major Project Phase I",
  "comp_sem7": "<b>Computer Engineering - Semester 7</b><br>• Elective III (Advanced AI / ML Ops)<br>• Elective IV (Blockchain / Cloud Security)<br>• Major Project Phase II<br>• Professional Ethics & Entrepreneurship",
  "comp_sem8": "<b>Computer Engineering - Semester 8</b><br>• Project Completion & Viva<br>• Elective V (Special Topics / Research)<br>• Industry Internship Report / Dissertation",

  "it_sem1": "<b>Information Technology - Semester 1</b><br>• Engineering Mathematics I<br>• Basic Electronics & Digital Logic<br>• Programming Fundamentals (Python/C) & Lab<br>• Engineering Graphics<br>• Environmental Studies",
  "it_sem2": "<b>Information Technology - Semester 2</b><br>• Engineering Mathematics II<br>• Data Structures I & Lab<br>• Discrete Mathematics<br>• Basic Communication Systems",
  "it_sem3": "<b>Information Technology - Semester 3</b><br>• Database Systems & Lab<br>• Data Structures II & Algorithms<br>• Computer Networks Basics<br>• Object Oriented Systems",
  "it_sem4": "<b>Information Technology - Semester 4</b><br>• Web Technologies<br>• Operating Systems & Lab<br>• Software Engineering<br>• Microservices / Cloud Basics",
  "it_sem5": "<b>Information Technology - Semester 5</b><br>• Data Analytics / Data Mining (elective)<br>• Web Security & Cybersecurity Basics<br>• Elective I - AI/ML<br>• Mini Project",
  "it_sem6": "<b>Information Technology - Semester 6</b><br>• Mobile App Development<br>• Cloud Computing & Lab<br>• Elective II - Big Data / DevOps<br>• Major Project Phase I",
  "it_sem7": "<b>Information Technology - Semester 7</b><br>• Advanced Web Systems<br>• Elective III - Blockchain / Cybersecurity<br>• Major Project Phase II<br>• Internship Report",
  "it_sem8": "<b>Information Technology - Semester 8</b><br>• Project Completion & Viva<br>• Elective IV - Special Topics",

  "entc_sem1": "<b>E&TC - Semester 1</b><br>• Engineering Mathematics I<br>• Basic Electronics & Circuits<br>• Engineering Physics/Chemistry<br>• Programming Basics & Lab<br>• Environmental Studies",
  "entc_sem2": "<b>E&TC - Semester 2</b><br>• Engineering Mathematics II<br>• Electronic Devices & Circuits<br>• Circuit Theory<br>• Digital Logic Design & Lab",
  "entc_sem3": "<b>E&TC - Semester 3</b><br>• Signals & Systems<br>• Analog Communications<br>• Digital Communications<br>• Microcontrollers & Lab",
  "entc_sem4": "<b>E&TC - Semester 4</b><br>• Electromagnetics basics<br>• Control Systems<br>• DSP basics & Lab<br>• Communication Systems Lab",
  "entc_sem5": "<b>E&TC - Semester 5</b><br>• RF & Microwave basics (elective)<br>• VLSI / Embedded Systems<br>• Digital Signal Processing advanced<br>• Mini Project",
  "entc_sem6": "<b>E&TC - Semester 6</b><br>• Wireless Communication<br>• Antenna & Wave Propagation (elective)<br>• Major Project Phase I",
  "entc_sem7": "<b>E&TC - Semester 7</b><br>• Elective topics (IoT, 5G, Image Processing)<br>• Major Project Phase II",
  "entc_sem8": "<b>E&TC - Semester 8</b><br>• Project Completion & Viva<br>• Elective Special Topics",

  "mech_sem1": "<b>Mechanical Engg - Semester 1</b><br>• Engineering Mathematics I<br>• Engineering Mechanics<br>• Basic Mechanical Workshop & Lab<br>• Material Science Basics<br>• Programming Basics",
  "mech_sem2": "<b>Mechanical Engg - Semester 2</b><br>• Engineering Mathematics II<br>• Strength of Materials Basics<br>• Thermodynamics Intro<br>• Manufacturing Processes & Lab",
  "mech_sem3": "<b>Mechanical Engg - Semester 3</b><br>• Fluid Mechanics I<br>• Thermodynamics II<br>• Machine Drawing / CAD basics<br>• Dynamics",
  "mech_sem4": "<b>Mechanical Engg - Semester 4</b><br>• Mechanics of Machines<br>• Manufacturing Technology<br>• Heat Transfer basics",
  "mech_sem5": "<b>Mechanical Engg - Semester 5</b><br>• Machine Design I<br>• IC Engines / Refrigeration & Air Conditioning<br>• Elective I",
  "mech_sem6": "<b>Mechanical Engg - Semester 6</b><br>• Machine Design II<br>• CAD/CAM applications<br>• Major Project Phase I",
  "mech_sem7": "<b>Mechanical Engg - Semester 7</b><br>• Elective topics (Robotics, Mechatronics)<br>• Major Project Phase II",
  "mech_sem8": "<b>Mechanical Engg - Semester 8</b><br>• Project Completion & Viva<br>• Industry Internship / Report",

  "mba_sem1": "<b>MBA - Term 1</b><br>• Organizational Behaviour<br>• Managerial Economics<br>• Accounting for Managers<br>• Quantitative Techniques",
  "mba_sem2": "<b>MBA - Term 2</b><br>• Marketing Management<br>• Financial Management<br>• Human Resource Management<br>• Operations Management",
  "mba_sem3": "<b>MBA - Term 3</b><br>• Strategic Management<br>• Electives (Finance/Marketing/HR/Operations/IT)<br>• Summer Internship Project",
  "mba_sem4": "<b>MBA - Term 4</b><br>• Electives & Dissertation / Project<br>• Industry Projects & Placements",

  /* ---------------------------
     ADMIN / STUDENT SERVICES
     --------------------------- */
  "training_cell": "🏫 <b>Training & Placement Cell</b><br>• Conducts workshops, mock interviews, resume building, and placement drives. Contact T&P for internship opportunities and placement registration.",
  "student_support": "👥 <b>Student Support Services</b><br>• Counselling, career guidance, disability support, mentoring & remedial coaching as required.",
  "transport_info": "🚌 <b>Transport & Bus Pass</b><br>• Apply at transport office for bus route allocation; update details each semester online.",
  "cafeteria": "☕ <b>Cafeteria & Food</b><br>• Multiple food outlets on campus with hygienic options. Feedback to student council for improvements.",
  "medical": "🩺 <b>Medical & First Aid</b><br>• On-campus medical room and first-aid. Emergency contacts available at admin office.",
  "anti_ragging_contact": "📣 <b>Anti-ragging & Helpline</b><br>• Report incidents to anti-ragging committee via email/portal. Confidential handling guaranteed.",

  /* ---------------------------
     ADMIN / ACADEMIC PROCEDURES
     --------------------------- */
  "exam_schedule": "📅 <b>Exam Schedule & Time-table</b><br>• Exam timetable published on student portal before each semester end. Follow registration deadlines.",
  "result_declaration": "📢 <b>Results & Transcripts</b><br>• Results declared on the university/ autonomous portal. Official transcripts available via admin office on request.",
  "revaluation_procedure": "🔁 <b>Revaluation / Photocopy</b><br>• Apply for revaluation/photocopy within stipulated dates with required fees. Results handled per exam controller timeline.",
  "fee_payment": "💳 <b>Fee Payment & Refunds</b><br>• Fees paid online via student portal. Refunds and concessions processed per institute rules.",
  "registration_portal": "🔐 <b>Student Portal</b><br>• Use the student portal for registrations, exam forms, attendance tracking, and accessing study material.",

  /* ---------------------------
     PLACEMENT & CAREER GUIDANCE
     --------------------------- */
  "placement_prep": "🧑‍💼 <b>Placement Preparation Tips</b><br>• Prepare solid resume, practice aptitude and coding problems, attend mock interviews, maintain projects on GitHub, network with alumni.",
  "career_guidance": "🔭 <b>Career & Higher Studies Guidance</b><br>• Guidance for higher studies (GATE, GRE, IELTS), certifications (AWS, Azure), and career counselling via training cell.",

  /* ---------------------------
     FEEDBACK & ANALYTICS
     --------------------------- */
  "feedback": "📝 <b>Feedback</b><br>You can share your feedback below. Feedback is anonymous and stored securely for improvement analyses.",
  "feedback_why": "ℹ️ <b>Why Feedback Matters</b><br>• Helps improve labs, curriculum, faculty support, events and student services. Admin reviews summarized feedback regularly.",

  /* ---------------------------
     MISCELLANEOUS
     --------------------------- */
  "hostel_rules": "🏨 <b>Hostel Rules & Curfew</b><br>• Follow hostel code of conduct, curfew timings, maintain cleanliness, visitors allowed only per rules, report issues to wardens.",
  "library_rules": "📘 <b>Library Rules</b><br>• Issue & return books on time, respect silent zones, use digital resources with institutional login.",
  "campus_safety": "🔐 <b>Campus Safety</b><br>• Security available 24/7, ID cards mandatory, emergency contact numbers displayed across campus.",
  "alumni_cell": "🤝 <b>Alumni & Industry Relations</b><br>• Alumni cell facilitates mentorship, placements, funding opportunities, and guest lectures.",
  "events_calendar": "🗓️ <b>Events Calendar</b><br>• Check the student portal for the official academic calendar, fest dates, and workshop schedules.",
  "student_achievements": "🏆 <b>Student Achievements</b><br>• Teams and students receive awards in tech competitions, sports meets, and cultural events. Achievement highlights published on the website.",

  /* ---------------------------
     HELPFUL SHORT LINKS / CONTACTS (display as text)
     --------------------------- */
  "website": "🌐 <b>Official Website</b><br>Visit the official MMCOE website and student portal for latest updates, circulars, and notices.",
  "admin_office": "🏢 <b>Admin Office</b><br>Contact admin office for admissions, certificates, and official documentation procedures.",
  "tp_contact": "📇 <b>Training & Placement Contact</b><br>training.placement@mmcoe.edu.in (use the official portal to register for drives)."
};


const chatMessages = document.getElementById("chatMessages");
const userInput = document.getElementById("userInput");

let feedbackMode = false;

// Add message
function addMessage(content, sender = "bot") {
  const messageEl = document.createElement("div");
  messageEl.classList.add("message", sender === "user" ? "user-message" : "bot-message");

  if (sender === "bot") {
    messageEl.innerHTML = `<div class="bot-avatar">M</div><div class="message-content">${content}</div>`;
  } else {
    messageEl.innerHTML = `<div class="message-content">${content}</div>`;
  }

  chatMessages.appendChild(messageEl);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Send message
window.sendMessage = async function() {
  const text = userInput.value.trim();
  if (!text) return;

  addMessage(text, "user");
  userInput.value = "";

  if (feedbackMode) {
    try {
      await saveFeedback("Anonymous", text);
      addMessage("✅ Your feedback has been saved. Thank you!", "bot");
    } catch (err) {
      console.error("Error saving feedback:", err);
      addMessage("❌ Failed to save feedback. Try again later.", "bot");
    }
    feedbackMode = false;
    return;
  }

  const key = text.toLowerCase().replace(/\s+/g, "_");
  if (key === "feedback") {
    feedbackMode = true;
    addMessage("Please type your feedback and press Enter:", "bot");
    return;
  }

  if (dataset[key]) {
    setTimeout(() => addMessage(dataset[key], "bot"), 600);
  } else {
    setTimeout(() => addMessage("🤖 Sorry, I don't have info on that yet.", "bot"), 600);
  }
};

// Enter key handler
userInput.addEventListener("keydown", function(e) {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Quick actions
function quickAction(key) {
  addMessage(key.replace("_", " "), "user");
  if (key === "feedback") {
    feedbackMode = true;
    addMessage("Please type your feedback and press Enter:", "bot");
    return;
  }
  
  if (dataset[key]) {
    setTimeout(() => addMessage(dataset[key], "bot"), 600);
  } else {
    setTimeout(() => addMessage("🤖 Sorry, no info on that.", "bot"), 600);
  }
}

// Save feedback (modular Firestore syntax)
async function saveFeedback(user, message) {
  try {
    await addDoc(collection(db, "feedback"), {
      user: user,
      message: message,
      timestamp: new Date()
    });
  } catch (error) {
    console.error("Firebase error:", error);
    throw error;
  }
}
addMessage("👋 Welcome to MMCOE Enquiry Assistant! How can I help you today?", "bot");
